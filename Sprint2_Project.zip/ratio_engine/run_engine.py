"""
run_engine.py
=============
Day 12 — Full Pipeline Runner

Orchestrates:
1. Data load (xlsx → SQLite or synthetic seed)
2. Ratio computation for all companies × all years
3. CAGR computation
4. Cash-flow KPIs & capital allocation
5. Edge case cross-checks
6. Write financial_ratios + capital_allocation tables
7. Export output/capital_allocation.csv
8. Sprint 2 verification queries
"""

from __future__ import annotations
import argparse
import csv
import logging
import sqlite3
import sys
from collections import defaultdict
from pathlib import Path
from typing import Optional

# ---- project imports -------------------------------------------------------
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from src.db.schema   import create_all_tables, get_connection, DB_PATH
from src.db.loader   import load_xlsx, seed_synthetic_data

from src.analytics.ratios       import compute_all_ratios
from src.analytics.cagr         import compute_cagr_for_year, build_series
from src.analytics.cashflow_kpis import compute_cashflow_kpis
from src.analytics.composite    import composite_quality_score
from src.analytics.edge_cases   import (
    apply_sector_carve_outs,
    check_roce_anomaly,
    check_roe_anomaly,
    is_financial_sector,
)

OUTPUT_DIR = ROOT / "output"
OUTPUT_DIR.mkdir(exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)-8s %(name)s — %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("run_engine")


# ---------------------------------------------------------------------------
# Fetch helpers
# ---------------------------------------------------------------------------

def fetch_companies(conn: sqlite3.Connection) -> list[dict]:
    rows = conn.execute("SELECT * FROM companies").fetchall()
    return [dict(r) for r in rows]


def fetch_financials_for_company(conn: sqlite3.Connection, company_id: str) -> list[dict]:
    rows = conn.execute(
        "SELECT f.*, c.broad_sector FROM financials f "
        "JOIN companies c ON c.company_id = f.company_id "
        "WHERE f.company_id = ? ORDER BY year",
        (company_id,),
    ).fetchall()
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Single-company pipeline
# ---------------------------------------------------------------------------

def process_company(
    conn: sqlite3.Connection,
    company_id: str,
    broad_sector: str,
) -> tuple[list[dict], list[dict]]:
    """
    Process one company across all years.

    Returns (ratio_rows, alloc_rows) ready for bulk insert.
    """
    rows = fetch_financials_for_company(conn, company_id)
    if not rows:
        return [], []

    # Build time series for CAGR
    revenue_series = build_series(rows, "sales")
    pat_series     = build_series(rows, "net_profit")
    eps_series     = build_series(rows, "eps")

    # Build CFO/PAT history for quality score (chronological)
    cfo_pat_history = [(r.get("operating_activity"), r.get("net_profit")) for r in rows]

    ratio_rows = []
    alloc_rows = []

    for i, row in enumerate(rows):
        year = row["year"]
        row["company_id"]  = company_id
        row["broad_sector"] = broad_sector

        # 1. Core ratios
        ratios = compute_all_ratios(row)

        # 2. CAGR
        cagrs = compute_cagr_for_year(revenue_series, pat_series, eps_series, year)

        # 3. Cash flow KPIs
        history_slice = cfo_pat_history[max(0, i - 4): i + 1]
        cf_kpis = compute_cashflow_kpis(row, cfo_pat_history=history_slice)

        # 4. Composite quality score
        comp = composite_quality_score(
            roe=ratios.get("return_on_equity_pct"),
            roce=ratios.get("return_on_capital_employed"),
            de=ratios.get("debt_to_equity"),
            icr=ratios.get("interest_coverage"),
            cfo_quality=cf_kpis.get("cfo_quality_score"),
            is_financial=is_financial_sector(broad_sector),
        )

        # 5. Edge case cross-checks
        check_roce_anomaly(company_id, year,
                           ratios.get("return_on_capital_employed"),
                           row.get("roce_percentage"))
        check_roe_anomaly(company_id, year,
                          ratios.get("return_on_equity_pct"),
                          row.get("roe_percentage"))

        # 6. Sector carve-outs
        full_row = {
            "company_id": company_id,
            "year":       year,
            **ratios,
            **cagrs,
            **{k: v for k, v in cf_kpis.items() if not k.startswith("_")},
            "composite_quality_score": comp,
        }
        full_row = apply_sector_carve_outs(full_row, broad_sector)
        ratio_rows.append(full_row)

        # 7. Capital allocation row
        alloc_rows.append({
            "company_id":   company_id,
            "year":         year,
            "cfo_sign":     cf_kpis.get("_cfo_sign"),
            "cfi_sign":     cf_kpis.get("_cfi_sign"),
            "cff_sign":     cf_kpis.get("_cff_sign"),
            "pattern_label": cf_kpis.get("capital_allocation_pattern"),
        })

    return ratio_rows, alloc_rows


# ---------------------------------------------------------------------------
# Bulk insert helpers
# ---------------------------------------------------------------------------

RATIO_COLS = [
    "company_id", "year",
    "net_profit_margin_pct", "operating_profit_margin_pct",
    "return_on_equity_pct", "return_on_capital_employed", "return_on_assets_pct",
    "debt_to_equity", "high_leverage_flag", "interest_coverage",
    "icr_label", "icr_warning_flag", "net_debt", "asset_turnover",
    "free_cash_flow_cr", "cash_from_operations_cr", "capex_cr",
    "capex_intensity_pct", "capex_intensity_label",
    "fcf_conversion_rate", "cfo_quality_score", "cfo_quality_label",
    "capital_allocation_pattern",
    "revenue_cagr_3yr", "revenue_cagr_3yr_flag",
    "revenue_cagr_5yr", "revenue_cagr_5yr_flag",
    "revenue_cagr_10yr", "revenue_cagr_10yr_flag",
    "pat_cagr_3yr", "pat_cagr_3yr_flag",
    "pat_cagr_5yr", "pat_cagr_5yr_flag",
    "pat_cagr_10yr", "pat_cagr_10yr_flag",
    "eps_cagr_3yr", "eps_cagr_3yr_flag",
    "eps_cagr_5yr", "eps_cagr_5yr_flag",
    "eps_cagr_10yr", "eps_cagr_10yr_flag",
    "earnings_per_share", "book_value_per_share",
    "dividend_payout_ratio_pct", "total_debt_cr",
    "composite_quality_score",
]


def bulk_insert_ratios(conn: sqlite3.Connection, rows: list[dict]) -> None:
    clean = [{c: r.get(c) for c in RATIO_COLS} for r in rows]
    ph = ", ".join(f":{c}" for c in RATIO_COLS)
    updates = ", ".join(f"{c}=excluded.{c}" for c in RATIO_COLS if c not in ("company_id", "year"))
    sql = (
        f"INSERT INTO financial_ratios ({', '.join(RATIO_COLS)}) VALUES ({ph}) "
        f"ON CONFLICT(company_id, year) DO UPDATE SET {updates}"
    )
    conn.executemany(sql, clean)


def bulk_insert_alloc(conn: sqlite3.Connection, rows: list[dict]) -> None:
    cols = ["company_id", "year", "cfo_sign", "cfi_sign", "cff_sign", "pattern_label"]
    ph = ", ".join(f":{c}" for c in cols)
    updates = ", ".join(f"{c}=excluded.{c}" for c in cols if c not in ("company_id", "year"))
    sql = (
        f"INSERT INTO capital_allocation ({', '.join(cols)}) VALUES ({ph}) "
        f"ON CONFLICT(company_id, year) DO UPDATE SET {updates}"
    )
    conn.executemany(sql, rows)


# ---------------------------------------------------------------------------
# Export CSV
# ---------------------------------------------------------------------------

def export_capital_allocation_csv(conn: sqlite3.Connection) -> None:
    path = OUTPUT_DIR / "capital_allocation.csv"
    rows = conn.execute(
        "SELECT company_id, year, cfo_sign, cfi_sign, cff_sign, pattern_label "
        "FROM capital_allocation ORDER BY company_id, year"
    ).fetchall()
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["company_id", "year", "cfo_sign", "cfi_sign", "cff_sign", "pattern_label"])
        writer.writeheader()
        writer.writerows([dict(r) for r in rows])
    logger.info("Exported capital_allocation.csv — %d rows", len(rows))


# ---------------------------------------------------------------------------
# Sprint 2 verification
# ---------------------------------------------------------------------------

def run_verification(conn: sqlite3.Connection) -> None:
    logger.info("=" * 60)
    logger.info("SPRINT 2 EXIT CRITERIA VERIFICATION")
    logger.info("=" * 60)

    # Row count
    count = conn.execute("SELECT COUNT(*) FROM financial_ratios").fetchone()[0]
    status = "✅ PASS" if count >= 1100 else "❌ FAIL"
    logger.info("[Row Count] %s — %d rows (need ≥ 1,100)", status, count)

    # All KPI columns populated (no null-only columns)
    kpi_cols = [c for c in RATIO_COLS if c not in ("company_id", "year", "icr_label",
                "icr_warning_flag", "high_leverage_flag", "capex_intensity_label",
                "cfo_quality_label", "capital_allocation_pattern",
                "revenue_cagr_3yr_flag", "revenue_cagr_5yr_flag", "revenue_cagr_10yr_flag",
                "pat_cagr_3yr_flag", "pat_cagr_5yr_flag", "pat_cagr_10yr_flag",
                "eps_cagr_3yr_flag", "eps_cagr_5yr_flag", "eps_cagr_10yr_flag")]
    for col in kpi_cols:
        try:
            non_null = conn.execute(
                f"SELECT COUNT(*) FROM financial_ratios WHERE {col} IS NOT NULL"
            ).fetchone()[0]
            if non_null == 0:
                logger.warning("[KPI Coverage] ❌ Column '%s' is ALL NULL", col)
        except sqlite3.OperationalError:
            logger.warning("[KPI Coverage] ⚠️  Column '%s' not found in table", col)

    # ROE screener sanity check: ROE > 15% AND D/E < 1
    screener = conn.execute(
        "SELECT COUNT(DISTINCT company_id) FROM financial_ratios "
        "WHERE return_on_equity_pct > 15 AND debt_to_equity < 1"
    ).fetchone()[0]
    status = "✅ PASS" if 15 <= screener <= 50 else "⚠️  WARN"
    logger.info("[Screener] %s — %d companies pass ROE>15%% AND D/E<1 (expect 15–50)", status, screener)

    # capital_allocation.csv
    csv_path = OUTPUT_DIR / "capital_allocation.csv"
    status = "✅ PASS" if csv_path.exists() else "❌ FAIL"
    logger.info("[CSV] %s — output/capital_allocation.csv", status)

    # ratio_edge_cases.log
    log_path = OUTPUT_DIR / "ratio_edge_cases.log"
    status = "✅ PASS" if log_path.exists() else "❌ FAIL"
    logger.info("[Log] %s — output/ratio_edge_cases.log", status)

    # Demo: 5 companies with all KPIs
    logger.info("\n--- Sample: 5 Companies (all KPIs) ---")
    sample = conn.execute(
        "SELECT company_id, year, net_profit_margin_pct, return_on_equity_pct, "
        "debt_to_equity, interest_coverage, revenue_cagr_5yr, composite_quality_score "
        "FROM financial_ratios WHERE year = (SELECT MAX(year) FROM financial_ratios) "
        "LIMIT 5"
    ).fetchall()
    for r in sample:
        logger.info(dict(r))

    logger.info("=" * 60)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description="Financial Ratio Engine — Sprint 2")
    parser.add_argument("--xlsx",   type=Path, help="Path to companies.xlsx", default=None)
    parser.add_argument("--db",     type=Path, default=DB_PATH, help="SQLite database path")
    parser.add_argument("--seed",   action="store_true", help="Seed synthetic data (no xlsx needed)")
    parser.add_argument("--verify", action="store_true", help="Run verification only")
    args = parser.parse_args()

    db_path: Path = args.db

    # ---- Data load --------------------------------------------------------
    if args.verify:
        pass  # skip load
    elif args.xlsx and args.xlsx.exists():
        logger.info("Loading data from %s", args.xlsx)
        load_xlsx(args.xlsx, db_path)
    else:
        logger.info("No xlsx provided — seeding synthetic data for 92 companies.")
        seed_synthetic_data(db_path)

    # ---- Process companies -----------------------------------------------
    with get_connection(db_path) as conn:
        if not args.verify:
            companies = fetch_companies(conn)
            logger.info("Processing %d companies...", len(companies))

            all_ratio_rows = []
            all_alloc_rows = []

            for co in companies:
                cid    = co["company_id"]
                sector = co.get("broad_sector", "")
                r_rows, a_rows = process_company(conn, cid, sector)
                all_ratio_rows.extend(r_rows)
                all_alloc_rows.extend(a_rows)

            logger.info("Inserting %d ratio rows...", len(all_ratio_rows))
            bulk_insert_ratios(conn, all_ratio_rows)
            bulk_insert_alloc(conn, all_alloc_rows)
            conn.commit()

            export_capital_allocation_csv(conn)

        run_verification(conn)


if __name__ == "__main__":
    main()
