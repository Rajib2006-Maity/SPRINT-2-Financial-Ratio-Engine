"""
src/db/schema.py
SQLite schema creation and migration for the Ratio Engine.
"""

import sqlite3
import logging
from pathlib import Path

DB_PATH = Path(__file__).resolve().parents[2] / "data" / "financials.db"

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# DDL
# ---------------------------------------------------------------------------

DDL_COMPANIES = """
CREATE TABLE IF NOT EXISTS companies (
    company_id      TEXT PRIMARY KEY,
    name            TEXT NOT NULL,
    broad_sector    TEXT,          -- e.g. 'Financials', 'Technology', ...
    ticker          TEXT,
    isin            TEXT
);
"""

DDL_FINANCIALS = """
CREATE TABLE IF NOT EXISTS financials (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id          TEXT NOT NULL,
    year                INTEGER NOT NULL,
    -- Income Statement
    sales               REAL,
    operating_profit    REAL,
    other_income        REAL,
    interest            REAL,
    depreciation        REAL,
    net_profit          REAL,
    eps                 REAL,
    -- Balance Sheet
    equity_capital      REAL,
    reserves            REAL,
    borrowings          REAL,
    total_assets        REAL,
    investments         REAL,
    -- Cash Flow
    operating_activity  REAL,   -- CFO
    investing_activity  REAL,   -- CFI
    financing_activity  REAL,   -- CFF
    -- Pre-computed reference columns (from source)
    opm_percentage      REAL,
    roce_percentage     REAL,
    roe_percentage      REAL,
    dividend_payout     REAL,
    book_value          REAL,
    UNIQUE(company_id, year),
    FOREIGN KEY(company_id) REFERENCES companies(company_id)
);
"""

DDL_FINANCIAL_RATIOS = """
CREATE TABLE IF NOT EXISTS financial_ratios (
    id                          INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id                  TEXT NOT NULL,
    year                        INTEGER NOT NULL,
    -- Profitability
    net_profit_margin_pct       REAL,
    operating_profit_margin_pct REAL,
    return_on_equity_pct        REAL,
    return_on_capital_employed  REAL,
    return_on_assets_pct        REAL,
    -- Leverage
    debt_to_equity              REAL,
    high_leverage_flag          INTEGER DEFAULT 0,  -- 1 = True
    interest_coverage           REAL,
    icr_label                   TEXT,               -- 'Debt Free' or NULL
    icr_warning_flag            INTEGER DEFAULT 0,
    net_debt                    REAL,
    -- Efficiency
    asset_turnover              REAL,
    -- Cash Flow KPIs
    free_cash_flow_cr           REAL,
    cash_from_operations_cr     REAL,
    capex_cr                    REAL,
    capex_intensity_pct         REAL,
    capex_intensity_label       TEXT,
    fcf_conversion_rate         REAL,
    cfo_quality_score           REAL,
    cfo_quality_label           TEXT,
    capital_allocation_pattern  TEXT,
    -- CAGR (5-year, primary)
    revenue_cagr_5yr            REAL,
    revenue_cagr_5yr_flag       TEXT,
    revenue_cagr_3yr            REAL,
    revenue_cagr_3yr_flag       TEXT,
    revenue_cagr_10yr           REAL,
    revenue_cagr_10yr_flag      TEXT,
    pat_cagr_5yr                REAL,
    pat_cagr_5yr_flag           TEXT,
    pat_cagr_3yr                REAL,
    pat_cagr_3yr_flag           TEXT,
    pat_cagr_10yr               REAL,
    pat_cagr_10yr_flag          TEXT,
    eps_cagr_5yr                REAL,
    eps_cagr_5yr_flag           TEXT,
    eps_cagr_3yr                REAL,
    eps_cagr_3yr_flag           TEXT,
    eps_cagr_10yr               REAL,
    eps_cagr_10yr_flag          TEXT,
    -- Per-share & composite
    earnings_per_share          REAL,
    book_value_per_share        REAL,
    dividend_payout_ratio_pct   REAL,
    total_debt_cr               REAL,
    composite_quality_score     REAL,
    UNIQUE(company_id, year),
    FOREIGN KEY(company_id) REFERENCES companies(company_id)
);
"""

DDL_CAPITAL_ALLOCATION = """
CREATE TABLE IF NOT EXISTS capital_allocation (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id      TEXT NOT NULL,
    year            INTEGER NOT NULL,
    cfo_sign        TEXT,
    cfi_sign        TEXT,
    cff_sign        TEXT,
    pattern_label   TEXT,
    UNIQUE(company_id, year)
);
"""


def get_connection(db_path: Path = DB_PATH) -> sqlite3.Connection:
    """Return a connection with foreign-key enforcement enabled."""
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.row_factory = sqlite3.Row
    return conn


def create_all_tables(db_path: Path = DB_PATH) -> None:
    """Create all tables if they don't exist."""
    with get_connection(db_path) as conn:
        for ddl in [DDL_COMPANIES, DDL_FINANCIALS, DDL_FINANCIAL_RATIOS, DDL_CAPITAL_ALLOCATION]:
            conn.execute(ddl)
        conn.commit()
    logger.info("All tables created / verified at %s", db_path)
