"""
src/db/loader.py
Reads companies.xlsx and seeds the companies + financials tables.

Expected sheet layout (adjust column names to match your actual file):
  Sheet "Companies" — one row per company
  Sheet "Financials" — one row per (company, year) with all P&L / BS / CF fields
"""

import logging
import sqlite3
from pathlib import Path
from typing import Optional

import pandas as pd

from src.db.schema import get_connection, create_all_tables, DB_PATH

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Column name maps  (source xlsx column → our canonical name)
# Adjust these to match the actual header names in your file.
# ---------------------------------------------------------------------------

COMPANY_COL_MAP = {
    "Company ID":   "company_id",
    "Name":         "name",
    "Broad Sector": "broad_sector",
    "Ticker":       "ticker",
    "ISIN":         "isin",
}

FINANCIAL_COL_MAP = {
    "Company ID":           "company_id",
    "Year":                 "year",
    "Sales":                "sales",
    "Operating Profit":     "operating_profit",
    "Other Income":         "other_income",
    "Interest":             "interest",
    "Depreciation":         "depreciation",
    "Net Profit":           "net_profit",
    "EPS":                  "eps",
    "Equity Capital":       "equity_capital",
    "Reserves":             "reserves",
    "Borrowings":           "borrowings",
    "Total Assets":         "total_assets",
    "Investments":          "investments",
    "Operating Activity":   "operating_activity",
    "Investing Activity":   "investing_activity",
    "Financing Activity":   "financing_activity",
    "OPM %":                "opm_percentage",
    "ROCE %":               "roce_percentage",
    "ROE %":                "roe_percentage",
    "Dividend Payout":      "dividend_payout",
    "Book Value":           "book_value",
}


def load_xlsx(
    xlsx_path: Path,
    db_path: Path = DB_PATH,
    company_sheet: str = "Companies",
    financial_sheet: str = "Financials",
) -> None:
    """Parse xlsx and upsert all rows into SQLite."""
    create_all_tables(db_path)

    xl = pd.ExcelFile(xlsx_path)
    sheet_names = xl.sheet_names
    logger.info("Sheets found: %s", sheet_names)

    # ---- Companies --------------------------------------------------------
    if company_sheet in sheet_names:
        df_co = xl.parse(company_sheet)
        df_co = _remap_columns(df_co, COMPANY_COL_MAP)
        _upsert_companies(df_co, db_path)
    else:
        logger.warning("Sheet '%s' not found — skipping companies load.", company_sheet)

    # ---- Financials -------------------------------------------------------
    if financial_sheet in sheet_names:
        df_fin = xl.parse(financial_sheet)
        df_fin = _remap_columns(df_fin, FINANCIAL_COL_MAP)
        _upsert_financials(df_fin, db_path)
    else:
        logger.warning("Sheet '%s' not found — skipping financials load.", financial_sheet)


def _remap_columns(df: pd.DataFrame, col_map: dict) -> pd.DataFrame:
    """Rename columns that exist in the map; drop unmapped ones."""
    rename = {k: v for k, v in col_map.items() if k in df.columns}
    df = df.rename(columns=rename)
    keep = list(col_map.values())
    return df[[c for c in keep if c in df.columns]]


def _upsert_companies(df: pd.DataFrame, db_path: Path) -> None:
    required = ["company_id", "name"]
    _check_required(df, required, "companies")
    rows = df.where(pd.notna(df), None).to_dict("records")
    sql = """
        INSERT INTO companies (company_id, name, broad_sector, ticker, isin)
        VALUES (:company_id, :name, :broad_sector, :ticker, :isin)
        ON CONFLICT(company_id) DO UPDATE SET
            name=excluded.name,
            broad_sector=excluded.broad_sector,
            ticker=excluded.ticker,
            isin=excluded.isin
    """
    with get_connection(db_path) as conn:
        conn.executemany(sql, rows)
        conn.commit()
    logger.info("Upserted %d company rows.", len(rows))


def _upsert_financials(df: pd.DataFrame, db_path: Path) -> None:
    required = ["company_id", "year"]
    _check_required(df, required, "financials")
    df["year"] = df["year"].astype(int)
    rows = df.where(pd.notna(df), None).to_dict("records")

    all_cols = [
        "company_id", "year", "sales", "operating_profit", "other_income",
        "interest", "depreciation", "net_profit", "eps", "equity_capital",
        "reserves", "borrowings", "total_assets", "investments",
        "operating_activity", "investing_activity", "financing_activity",
        "opm_percentage", "roce_percentage", "roe_percentage",
        "dividend_payout", "book_value",
    ]
    # Fill missing keys so executemany doesn't fail
    rows = [{c: r.get(c) for c in all_cols} for r in rows]

    placeholders = ", ".join(f":{c}" for c in all_cols)
    updates = ", ".join(f"{c}=excluded.{c}" for c in all_cols if c not in ("company_id", "year"))
    sql = f"""
        INSERT INTO financials ({', '.join(all_cols)})
        VALUES ({placeholders})
        ON CONFLICT(company_id, year) DO UPDATE SET {updates}
    """
    with get_connection(db_path) as conn:
        conn.executemany(sql, rows)
        conn.commit()
    logger.info("Upserted %d financial rows.", len(rows))


def _check_required(df: pd.DataFrame, cols: list, table: str) -> None:
    missing = [c for c in cols if c not in df.columns]
    if missing:
        raise ValueError(f"[{table}] Missing required columns after remap: {missing}")


# ---------------------------------------------------------------------------
# Seed synthetic data (used when no xlsx is available — for testing)
# ---------------------------------------------------------------------------

def seed_synthetic_data(db_path: Path = DB_PATH, n_companies: int = 92) -> None:
    """
    Generate synthetic but realistic financial data for 92 companies
    across 15 years (FY2010–FY2024).  Covers all edge cases required by Sprint 2.
    """
    import random, math
    random.seed(42)

    create_all_tables(db_path)

    SECTORS = [
        "Technology", "Consumer", "Industrials", "Healthcare",
        "Energy", "Materials", "Financials",
    ]
    FINANCIAL_IDS = {f"CO{i:03d}" for i in range(1, 20)}  # 19 financial companies

    companies = []
    for i in range(1, n_companies + 1):
        cid = f"CO{i:03d}"
        sector = "Financials" if cid in FINANCIAL_IDS else random.choice(SECTORS[:6])
        companies.append({
            "company_id": cid,
            "name": f"Company {i} Ltd",
            "broad_sector": sector,
            "ticker": f"TICK{i}",
            "isin": f"IN{i:010d}",
        })

    financials = []
    for co in companies:
        cid = co["company_id"]
        base_sales = random.uniform(500, 50_000)

        for yr in range(2010, 2025):
            growth = random.uniform(0.85, 1.20)
            base_sales *= growth
            sales = round(base_sales, 2)

            opm = random.uniform(5, 35) / 100
            op = round(sales * opm, 2)
            other_income = round(random.uniform(0, sales * 0.05), 2)
            interest = round(random.uniform(0, op * 0.6), 2)
            dep = round(sales * random.uniform(0.01, 0.08), 2)
            tax_rate = random.uniform(0.20, 0.35)
            ebt = op + other_income - interest - dep
            net_profit = round(ebt * (1 - tax_rate), 2)

            equity = round(random.uniform(10, 500), 2)
            reserves = round(random.uniform(500, 30_000), 2)

            # Edge case: some companies have negative equity in early years
            if cid == "CO005" and yr < 2015:
                reserves = -abs(reserves)

            borrowings = round(random.uniform(0, (equity + max(reserves, 0)) * 8), 2)
            # Debt-free edge case — zero both borrowings AND interest
            if cid == "CO010":
                borrowings = 0.0
                interest   = 0.0

            # CAGR turnaround edge case: CO007 transitions loss→profit around 2015
            if cid == "CO007" and yr < 2016:
                net_profit = -abs(net_profit)

            # CAGR decline-to-loss edge case: CO008 turns profitable→loss after 2020
            if cid == "CO008" and yr > 2019:
                net_profit = -abs(net_profit)

            total_assets = round(equity + max(reserves, 0) + borrowings + random.uniform(100, 5000), 2)
            investments = round(total_assets * random.uniform(0.05, 0.25), 2)

            cfo = round(net_profit * random.uniform(0.5, 1.5), 2)
            cfi = round(-abs(sales * random.uniform(0.02, 0.15)), 2)
            cff = round(random.uniform(-5000, 5000), 2)

            eps = round(net_profit / random.uniform(50, 500), 2)

            financials.append({
                "company_id": cid, "year": yr,
                "sales": sales, "operating_profit": op,
                "other_income": other_income, "interest": interest,
                "depreciation": dep, "net_profit": net_profit,
                "eps": eps, "equity_capital": equity, "reserves": reserves,
                "borrowings": borrowings, "total_assets": total_assets,
                "investments": investments,
                "operating_activity": cfo, "investing_activity": cfi,
                "financing_activity": cff,
                "opm_percentage": round(opm * 100, 2),
                "roce_percentage": None, "roe_percentage": None,
                "dividend_payout": round(random.uniform(0, 50), 2),
                "book_value": round((equity + max(reserves, 0)) / random.uniform(50, 500), 2),
            })

    with get_connection(db_path) as conn:
        conn.executemany(
            """INSERT OR REPLACE INTO companies (company_id, name, broad_sector, ticker, isin)
               VALUES (:company_id,:name,:broad_sector,:ticker,:isin)""",
            companies,
        )
        cols = list(financials[0].keys())
        ph = ", ".join(f":{c}" for c in cols)
        conn.executemany(
            f"INSERT OR REPLACE INTO financials ({','.join(cols)}) VALUES ({ph})",
            financials,
        )
        conn.commit()

    logger.info(
        "Seeded %d companies × 15 years = %d financial rows.",
        len(companies), len(financials),
    )
