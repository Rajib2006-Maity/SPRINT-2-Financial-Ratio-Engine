"""
src/analytics/cagr.py
=====================
Day 10 — CAGR Engine

Computes Revenue, PAT, and EPS CAGR for 3-year, 5-year, and 10-year windows.

Edge-case flags
---------------
NORMAL           — both endpoints positive, result computed.
DECLINE_TO_LOSS  — start > 0, end < 0 (profitable → loss).
TURNAROUND       — start < 0, end > 0 (loss → profitable).
BOTH_NEGATIVE    — both endpoints negative.
ZERO_BASE        — start value = 0 (division undefined).
INSUFFICIENT     — fewer than n+1 data points available.
"""

from __future__ import annotations
import math
from typing import Optional

# ---------------------------------------------------------------------------
# Core CAGR formula
# ---------------------------------------------------------------------------

def cagr(start: Optional[float], end: Optional[float], n: int) -> tuple[Optional[float], str]:
    """
    Compute CAGR = ((end / start) ^ (1 / n) − 1) × 100.

    Parameters
    ----------
    start : float | None — value at the beginning of the period.
    end   : float | None — value at the end of the period.
    n     : int          — number of years in the window.

    Returns
    -------
    (cagr_value, flag)
        cagr_value — float (%) or None on any non-computable case.
        flag       — one of the 6 edge-case strings.
    """
    if start is None or end is None or n <= 0:
        return None, "INSUFFICIENT"

    if start == 0:
        return None, "ZERO_BASE"

    if start > 0 and end > 0:
        try:
            value = (math.pow(end / start, 1.0 / n) - 1) * 100
            return round(value, 4), "NORMAL"
        except (ValueError, ZeroDivisionError):
            return None, "ZERO_BASE"

    if start > 0 and end < 0:
        return None, "DECLINE_TO_LOSS"

    if start < 0 and end > 0:
        return None, "TURNAROUND"

    if start < 0 and end < 0:
        return None, "BOTH_NEGATIVE"

    return None, "ZERO_BASE"


# ---------------------------------------------------------------------------
# Window helper
# ---------------------------------------------------------------------------

def _window_values(
    series: dict[int, Optional[float]],
    end_year: int,
    n: int,
) -> tuple[Optional[float], Optional[float], int]:
    """
    Look up start and end values for an n-year window ending at end_year.

    Returns (start_value, end_value, actual_n)
    Returns (None, None, 0) when data is insufficient.
    """
    start_year = end_year - n
    start_val = series.get(start_year)
    end_val   = series.get(end_year)

    if start_val is None or end_val is None:
        return None, None, 0

    return start_val, end_val, n


# ---------------------------------------------------------------------------
# Per-metric CAGR computation across all years
# ---------------------------------------------------------------------------

def compute_metric_cagr(
    series: dict[int, Optional[float]],
    windows: tuple[int, ...] = (3, 5, 10),
) -> dict[str, Optional[float] | str]:
    """
    For a single metric time-series (year → value), compute CAGR for every
    combination of end_year × window.

    Returns a flat dict keyed as:
        cagr_{n}yr         — CAGR value (float %) or None
        cagr_{n}yr_flag    — edge-case label string
    """
    result: dict = {}
    end_years = sorted(series.keys())

    for n in windows:
        values_by_year: dict[int, tuple] = {}
        for ey in end_years:
            sv, ev, actual_n = _window_values(series, ey, n)
            if actual_n == 0:
                values_by_year[ey] = (None, "INSUFFICIENT")
            else:
                values_by_year[ey] = cagr(sv, ev, actual_n)
        result[f"cagr_{n}yr"] = values_by_year

    return result


# ---------------------------------------------------------------------------
# Full company CAGR block — called once per (company, year) during pipeline
# ---------------------------------------------------------------------------

def compute_cagr_for_year(
    revenue_series: dict[int, Optional[float]],
    pat_series:     dict[int, Optional[float]],
    eps_series:     dict[int, Optional[float]],
    end_year: int,
    windows: tuple[int, ...] = (3, 5, 10),
) -> dict[str, Optional[float] | str | None]:
    """
    Compute all CAGR columns for a single (company, end_year) observation.

    Returns a flat dict with columns:
        revenue_cagr_3yr, revenue_cagr_3yr_flag,
        revenue_cagr_5yr, revenue_cagr_5yr_flag,
        revenue_cagr_10yr, revenue_cagr_10yr_flag,
        pat_cagr_{n}yr, pat_cagr_{n}yr_flag,
        eps_cagr_{n}yr, eps_cagr_{n}yr_flag,
    """
    out: dict = {}
    metrics = {
        "revenue": revenue_series,
        "pat":     pat_series,
        "eps":     eps_series,
    }

    for metric_name, series in metrics.items():
        for n in windows:
            sv, ev, actual_n = _window_values(series, end_year, n)
            if actual_n == 0:
                val, flag = None, "INSUFFICIENT"
            else:
                val, flag = cagr(sv, ev, actual_n)
            out[f"{metric_name}_cagr_{n}yr"]        = val
            out[f"{metric_name}_cagr_{n}yr_flag"]   = flag

    return out


# ---------------------------------------------------------------------------
# Build series dicts from a list of (year, value) tuples
# ---------------------------------------------------------------------------

def build_series(rows: list[dict], value_col: str) -> dict[int, Optional[float]]:
    """
    Convert a list of dicts with 'year' and value_col into {year: value}.
    Keeps None values so the window helper can detect gaps.
    """
    return {r["year"]: r.get(value_col) for r in rows}
