"""
src/analytics/screener.py
==========================
Day 14 — Screener Preview

Quick filter engine over the financial_ratios table.
Supports dynamic threshold-based filtering with human-readable output.
"""

from __future__ import annotations
import logging
import sqlite3
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from src.db.schema import get_connection, DB_PATH

logger = logging.getLogger(__name__)


@dataclass
class ScreenerCriteria:
    """Define a set of min/max thresholds for ratio columns."""
    roe_min:        Optional[float] = None   # return_on_equity_pct
    roe_max:        Optional[float] = None
    de_min:         Optional[float] = None   # debt_to_equity
    de_max:         Optional[float] = None
    npm_min:        Optional[float] = None   # net_profit_margin_pct
    roce_min:       Optional[float] = None   # return_on_capital_employed
    icr_min:        Optional[float] = None   # interest_coverage
    revenue_cagr_min: Optional[float] = None # revenue_cagr_5yr
    composite_min:  Optional[float] = None   # composite_quality_score
    year:           Optional[int]   = None   # restrict to a single year


@dataclass
class ScreenerResult:
    company_id:                 str
    year:                       int
    return_on_equity_pct:       Optional[float]
    debt_to_equity:             Optional[float]
    net_profit_margin_pct:      Optional[float]
    return_on_capital_employed: Optional[float]
    interest_coverage:          Optional[float]
    revenue_cagr_5yr:           Optional[float]
    composite_quality_score:    Optional[float]
    icr_label:                  Optional[str]


def run_screener(
    criteria: ScreenerCriteria,
    db_path: Path = DB_PATH,
    limit: int = 200,
) -> list[ScreenerResult]:
    """
    Execute a parameterised screener query against the financial_ratios table.

    Returns a list of ScreenerResult objects sorted by composite_quality_score DESC.
    """
    conditions: list[str]   = []
    params:     list[float] = []

    _add_condition(conditions, params, "return_on_equity_pct",       ">=", criteria.roe_min)
    _add_condition(conditions, params, "return_on_equity_pct",       "<=", criteria.roe_max)
    _add_condition(conditions, params, "debt_to_equity",             ">=", criteria.de_min)
    _add_condition(conditions, params, "debt_to_equity",             "<=", criteria.de_max)
    _add_condition(conditions, params, "net_profit_margin_pct",      ">=", criteria.npm_min)
    _add_condition(conditions, params, "return_on_capital_employed", ">=", criteria.roce_min)
    _add_condition(conditions, params, "interest_coverage",          ">=", criteria.icr_min)
    _add_condition(conditions, params, "revenue_cagr_5yr",           ">=", criteria.revenue_cagr_min)
    _add_condition(conditions, params, "composite_quality_score",    ">=", criteria.composite_min)

    if criteria.year is not None:
        conditions.append("year = ?")
        params.append(criteria.year)

    where_clause = ("WHERE " + " AND ".join(conditions)) if conditions else ""

    sql = f"""
        SELECT
            company_id, year,
            return_on_equity_pct, debt_to_equity,
            net_profit_margin_pct, return_on_capital_employed,
            interest_coverage, revenue_cagr_5yr,
            composite_quality_score, icr_label
        FROM financial_ratios
        {where_clause}
        ORDER BY composite_quality_score DESC NULLS LAST
        LIMIT {limit}
    """

    with get_connection(db_path) as conn:
        rows = conn.execute(sql, params).fetchall()

    results = [ScreenerResult(**dict(r)) for r in rows]
    logger.info("Screener returned %d results.", len(results))
    return results


def _add_condition(
    conditions: list,
    params: list,
    column: str,
    operator: str,
    value: Optional[float],
) -> None:
    if value is not None:
        conditions.append(f"{column} IS NOT NULL AND {column} {operator} ?")
        params.append(value)


def print_screener_results(results: list[ScreenerResult]) -> None:
    """Pretty-print screener results to stdout."""
    if not results:
        print("No companies matched the screener criteria.")
        return

    print(f"\n{'Company':<10} {'Year':<6} {'ROE%':>7} {'D/E':>6} {'NPM%':>7} "
          f"{'ROCE%':>7} {'ICR':>7} {'RevCAGR':>8} {'QScore':>8}")
    print("-" * 75)
    for r in results:
        icr_display = r.icr_label or _fmt(r.interest_coverage)
        print(
            f"{r.company_id:<10} {r.year:<6} "
            f"{_fmt(r.return_on_equity_pct):>7} "
            f"{_fmt(r.debt_to_equity):>6} "
            f"{_fmt(r.net_profit_margin_pct):>7} "
            f"{_fmt(r.return_on_capital_employed):>7} "
            f"{icr_display:>7} "
            f"{_fmt(r.revenue_cagr_5yr):>8} "
            f"{_fmt(r.composite_quality_score):>8}"
        )
    print(f"\nTotal: {len(results)} companies")


def _fmt(val: Optional[float]) -> str:
    return f"{val:.1f}" if val is not None else "—"


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Financial Ratio Screener")
    parser.add_argument("--roe-min",          type=float, default=15.0)
    parser.add_argument("--de-max",           type=float, default=1.0)
    parser.add_argument("--npm-min",          type=float, default=None)
    parser.add_argument("--roce-min",         type=float, default=None)
    parser.add_argument("--revenue-cagr-min", type=float, default=None)
    parser.add_argument("--composite-min",    type=float, default=None)
    parser.add_argument("--year",             type=int,   default=None)
    parser.add_argument("--db",               type=Path,  default=DB_PATH)
    args = parser.parse_args()

    criteria = ScreenerCriteria(
        roe_min        = args.roe_min,
        de_max         = args.de_max,
        npm_min        = args.npm_min,
        roce_min       = args.roce_min,
        revenue_cagr_min = args.revenue_cagr_min,
        composite_min  = args.composite_min,
        year           = args.year,
    )

    results = run_screener(criteria, db_path=args.db)
    print_screener_results(results)
