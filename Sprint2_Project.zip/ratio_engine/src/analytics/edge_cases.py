"""
src/analytics/edge_cases.py
============================
Day 13 — Bank ROCE Carve-Out & Edge Case Log

Handles:
- Suppressing high-leverage flag for Financials sector companies.
- Cross-checking computed ROCE/ROE against source pre-computed values.
- Writing anomalies to output/ratio_edge_cases.log with a category label.
"""

from __future__ import annotations
import logging
from enum import Enum
from pathlib import Path
from typing import Optional

LOG_PATH = Path(__file__).resolve().parents[2] / "output" / "ratio_edge_cases.log"


class AnomalyCategory(str, Enum):
    DATA_SOURCE    = "data_source_issue"
    VERSION_DIFF   = "version_difference"
    FORMULA_DISC   = "formula_discrepancy"
    SUPPRESSED     = "suppressed_for_sector"


# Set up a dedicated file handler for anomaly logging
def _get_anomaly_logger() -> logging.Logger:
    logger = logging.getLogger("edge_cases")
    if not logger.handlers:
        LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        fh = logging.FileHandler(LOG_PATH, mode="a", encoding="utf-8")
        fh.setLevel(logging.DEBUG)
        fmt = logging.Formatter("%(asctime)s | %(levelname)-8s | %(message)s", datefmt="%Y-%m-%d %H:%M:%S")
        fh.setFormatter(fmt)
        logger.addHandler(fh)
        logger.setLevel(logging.DEBUG)
        logger.propagate = False
    return logger


anomaly_log = _get_anomaly_logger()


# ---------------------------------------------------------------------------
# Bank / Financials carve-out
# ---------------------------------------------------------------------------

FINANCIALS_SECTOR = "financials"


def is_financial_sector(broad_sector: Optional[str]) -> bool:
    return (broad_sector or "").strip().lower() == FINANCIALS_SECTOR


def apply_sector_carve_outs(ratio_row: dict, broad_sector: Optional[str]) -> dict:
    """
    For Financials sector companies:
    - Suppress high_leverage_flag (high D/E is structurally normal for banks/NBFCs).
    """
    if is_financial_sector(broad_sector):
        if ratio_row.get("high_leverage_flag"):
            ratio_row["high_leverage_flag"] = 0
            anomaly_log.info(
                "SUPPRESSED | %s FY%s | high_leverage_flag suppressed — Financials sector | %s",
                ratio_row.get("company_id", "?"),
                ratio_row.get("year", "?"),
                AnomalyCategory.SUPPRESSED,
            )
    return ratio_row


# ---------------------------------------------------------------------------
# Cross-check ROCE
# ---------------------------------------------------------------------------

ROCE_THRESHOLD = 5.0   # % difference that triggers a log entry


def check_roce_anomaly(
    company_id: str,
    year: int,
    computed_roce: Optional[float],
    source_roce: Optional[float],
) -> Optional[AnomalyCategory]:
    """
    Compare computed ROCE against the source pre-computed value.
    Logs an entry if |difference| > 5%.
    Returns the anomaly category assigned, or None.
    """
    if computed_roce is None or source_roce is None:
        return None

    diff = abs(computed_roce - source_roce)
    if diff <= ROCE_THRESHOLD:
        return None

    # Assign a preliminary category heuristic
    if diff > 30:
        category = AnomalyCategory.FORMULA_DISC
    elif diff > 10:
        category = AnomalyCategory.VERSION_DIFF
    else:
        category = AnomalyCategory.DATA_SOURCE

    anomaly_log.warning(
        "ROCE_MISMATCH | %s FY%s | computed=%.2f%% source=%.2f%% diff=%.2f%% | %s",
        company_id, year, computed_roce, source_roce, diff, category.value,
    )
    return category


# ---------------------------------------------------------------------------
# Cross-check ROE
# ---------------------------------------------------------------------------

ROE_ANOMALY_THRESHOLD = 10.0   # % points


def check_roe_anomaly(
    company_id: str,
    year: int,
    computed_roe: Optional[float],
    source_roe: Optional[float],
) -> Optional[AnomalyCategory]:
    """
    Compare computed ROE against source value.
    Note: Some source values are known to be anomalous (e.g. TCS = 0.52),
    so we only log but continue using computed_roe for analytics.
    """
    if computed_roe is None or source_roe is None:
        return None

    diff = abs(computed_roe - source_roe)
    if diff <= ROE_ANOMALY_THRESHOLD:
        return None

    # Special known anomaly: extremely small source value (likely decimal not %)
    if 0 < source_roe < 1.0:
        category = AnomalyCategory.DATA_SOURCE
        anomaly_log.warning(
            "ROE_MISMATCH | %s FY%s | computed=%.2f%% source=%.4f (likely decimal, not %%) | %s",
            company_id, year, computed_roe, source_roe, category.value,
        )
    else:
        category = AnomalyCategory.VERSION_DIFF
        anomaly_log.warning(
            "ROE_MISMATCH | %s FY%s | computed=%.2f%% source=%.2f%% diff=%.2f%% | %s",
            company_id, year, computed_roe, source_roe, diff, category.value,
        )
    return category
