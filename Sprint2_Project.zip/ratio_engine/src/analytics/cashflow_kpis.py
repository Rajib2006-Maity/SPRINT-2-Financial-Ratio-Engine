"""
src/analytics/cashflow_kpis.py
==============================
Day 11 — Cash Flow KPIs & Capital Allocation

Functions
---------
free_cash_flow          — FCF = CFO + CFI  (negative is valid)
cfo_quality_score       — CFO/PAT averaged over 5 years → label
capex_intensity         — |CFI| / Sales × 100 → label
fcf_conversion_rate     — FCF / Operating Profit × 100
capital_allocation      — sign(CFO, CFI, CFF) → 8-pattern label
"""

from __future__ import annotations
from typing import Optional

# ---------------------------------------------------------------------------
# FCF
# ---------------------------------------------------------------------------

def free_cash_flow(
    operating_activity: Optional[float],
    investing_activity: Optional[float],
) -> float:
    """
    FCF = CFO + CFI.
    Negative FCF is allowed and meaningful (capex-heavy growth phase).
    """
    return (operating_activity or 0.0) + (investing_activity or 0.0)


# ---------------------------------------------------------------------------
# CFO Quality Score
# ---------------------------------------------------------------------------

_CFO_QUALITY_THRESHOLDS = [
    (1.0, "High Quality"),
    (0.5, "Moderate"),
    (float("-inf"), "Accrual Risk"),
]


def cfo_quality_score(
    cfo_pat_pairs: list[tuple[Optional[float], Optional[float]]],
) -> tuple[Optional[float], Optional[str]]:
    """
    CFO Quality Score = average(CFO / PAT) over up to 5 years.

    Parameters
    ----------
    cfo_pat_pairs : list of (CFO, PAT) tuples, most recent last.
                    Pairs where PAT = 0 are skipped.

    Returns
    -------
    (score, label)
        score — average CFO/PAT ratio, or None if no valid pairs.
        label — 'High Quality', 'Moderate', or 'Accrual Risk'.
    """
    valid = [
        (cfo or 0.0) / pat
        for cfo, pat in cfo_pat_pairs
        if pat is not None and pat != 0
    ]
    if not valid:
        return None, None

    avg = sum(valid) / len(valid)

    for threshold, label in _CFO_QUALITY_THRESHOLDS:
        if avg >= threshold:
            return round(avg, 4), label

    return round(avg, 4), "Accrual Risk"


# ---------------------------------------------------------------------------
# CapEx Intensity
# ---------------------------------------------------------------------------

_CAPEX_LABELS = [
    (8.0, "Capital Intensive"),
    (3.0, "Moderate"),
    (0.0, "Asset Light"),
]


def capex_intensity(
    investing_activity: Optional[float],
    sales: Optional[float],
) -> tuple[Optional[float], Optional[str]]:
    """
    CapEx Intensity = |CFI| / Sales × 100.

    Returns (pct, label) or (None, None) if sales = 0 / None.
    Labels: <3% = Asset Light, 3-8% = Moderate, >8% = Capital Intensive.
    """
    if not sales:
        return None, None
    pct = abs(investing_activity or 0.0) / sales * 100

    for threshold, label in sorted(_CAPEX_LABELS, reverse=True):
        if pct >= threshold:
            return round(pct, 4), label

    return round(pct, 4), "Asset Light"


# ---------------------------------------------------------------------------
# FCF Conversion Rate
# ---------------------------------------------------------------------------

def fcf_conversion_rate(
    fcf: Optional[float],
    operating_profit: Optional[float],
) -> Optional[float]:
    """
    FCF Conversion = FCF / Operating Profit × 100.
    Returns None if operating_profit = 0 or None.
    """
    if not operating_profit:
        return None
    return round((fcf or 0.0) / operating_profit * 100, 4)


# ---------------------------------------------------------------------------
# Capital Allocation Pattern (8-pattern classifier)
# ---------------------------------------------------------------------------

def _sign(value: Optional[float]) -> str:
    """Return '+' or '-' for the sign of value (0 treated as '+')."""
    return "+" if (value or 0.0) >= 0 else "-"


_PATTERN_MAP: dict[tuple[str, str, str], str] = {
    ("+", "-", "-"): "Reinvestor",               # classic operating + reinvesting
    ("+", "+", "-"): "Liquidating Assets",        # selling assets
    ("-", "+", "+"): "Distress Signal",           # burning cash, selling assets, raising funds
    ("-", "-", "+"): "Growth Funded by Debt",
    ("+", "+", "+"): "Cash Accumulator",
    ("-", "-", "-"): "Pre-Revenue",
    ("+", "-", "+"): "Mixed",                     # mixed funding
    ("-", "+", "-"): "Distress Signal",           # selling + paying debt while operating cash burn
}

# High CFO/PAT variant of Reinvestor is labeled separately at display layer
_SHAREHOLDER_RETURNS_THRESHOLD = 1.5  # CFO/PAT threshold


def capital_allocation_pattern(
    cfo: Optional[float],
    cfi: Optional[float],
    cff: Optional[float],
    cfo_pat_ratio: Optional[float] = None,
) -> tuple[str, str, str, str]:
    """
    Classify capital allocation into one of 8 patterns.

    Parameters
    ----------
    cfo, cfi, cff   — cash from operations, investing, financing.
    cfo_pat_ratio   — optional CFO/PAT for the 'Shareholder Returns' sub-pattern.

    Returns
    -------
    (cfo_sign, cfi_sign, cff_sign, pattern_label)
    """
    cs, ci, cf = _sign(cfo), _sign(cfi), _sign(cff)
    key = (cs, ci, cf)

    label = _PATTERN_MAP.get(key, "Mixed")

    # Upgrade Reinvestor → Shareholder Returns when CFO/PAT is high
    if label == "Reinvestor" and cfo_pat_ratio is not None:
        if cfo_pat_ratio >= _SHAREHOLDER_RETURNS_THRESHOLD:
            label = "Shareholder Returns"

    return cs, ci, cf, label


# ---------------------------------------------------------------------------
# Composite — one row
# ---------------------------------------------------------------------------

def compute_cashflow_kpis(
    row: dict,
    cfo_pat_history: list[tuple[Optional[float], Optional[float]]] | None = None,
) -> dict:
    """
    Compute all cash-flow KPIs for a single (company, year) row.

    Parameters
    ----------
    row              — dict with keys: operating_activity, investing_activity,
                       financing_activity, net_profit, sales, operating_profit.
    cfo_pat_history  — list of (CFO, PAT) for last 5 years (including current),
                       used for CFO quality score.

    Returns a flat dict of all cashflow KPI columns.
    """
    cfo = row.get("operating_activity")
    cfi = row.get("investing_activity")
    cff = row.get("financing_activity")
    sales = row.get("sales")
    op   = row.get("operating_profit")
    pat  = row.get("net_profit")

    fcf = free_cash_flow(cfo, cfi)

    # CFO quality (requires history; fallback to single-year if no history)
    if cfo_pat_history:
        cq_score, cq_label = cfo_quality_score(cfo_pat_history[-5:])
    else:
        cq_score, cq_label = cfo_quality_score([(cfo, pat)])

    cap_pct, cap_label = capex_intensity(cfi, sales)
    fcf_conv           = fcf_conversion_rate(fcf, op)
    cfo_pat_ratio      = (cfo / pat) if (pat and pat != 0 and cfo is not None) else None
    cs, ci, cf, pattern = capital_allocation_pattern(cfo, cfi, cff, cfo_pat_ratio)

    return {
        "free_cash_flow_cr":        round(fcf, 4) if fcf is not None else None,
        "cfo_quality_score":        cq_score,
        "cfo_quality_label":        cq_label,
        "capex_intensity_pct":      cap_pct,
        "capex_intensity_label":    cap_label,
        "fcf_conversion_rate":      fcf_conv,
        "capital_allocation_pattern": pattern,
        # sign columns stored in capital_allocation table
        "_cfo_sign":                cs,
        "_cfi_sign":                ci,
        "_cff_sign":                cf,
    }
