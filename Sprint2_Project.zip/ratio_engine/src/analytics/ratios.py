"""
src/analytics/ratios.py
=======================
Day 08 — Profitability Ratios
Day 09 — Leverage & Efficiency Ratios

All functions accept plain numeric arguments (or None) and return a value
(or None on invalid denominator) plus optional flag metadata.

Convention
----------
- Return None  → mathematically undefined / data quality issue.
- Return 0     → logically valid zero (e.g. no debt → D/E = 0).
- All percentage outputs are in % units (multiply by 100 done inside).
"""

from __future__ import annotations
import logging
from typing import Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

def _safe_div(numerator: Optional[float], denominator: Optional[float]) -> Optional[float]:
    """Return numerator / denominator, or None if denominator is 0 / None."""
    if denominator is None or denominator == 0:
        return None
    if numerator is None:
        return None
    return numerator / denominator


# ===========================================================================
# DAY 08 — PROFITABILITY RATIOS
# ===========================================================================

def net_profit_margin(net_profit: Optional[float], sales: Optional[float]) -> Optional[float]:
    """
    Net Profit Margin = (net_profit / sales) × 100
    Returns None if sales = 0 or None.
    """
    result = _safe_div(net_profit, sales)
    if result is None:
        return None
    return result * 100


def operating_profit_margin(
    operating_profit: Optional[float],
    sales: Optional[float],
    source_opm: Optional[float] = None,
    company_id: str = "",
    year: int = 0,
) -> Optional[float]:
    """
    Operating Profit Margin = (operating_profit / sales) × 100
    Cross-checks against source opm_percentage; logs if difference > 1%.
    """
    result = _safe_div(operating_profit, sales)
    if result is None:
        return None
    computed = result * 100

    if source_opm is not None:
        diff = abs(computed - source_opm)
        if diff > 1.0:
            logger.warning(
                "[OPM MISMATCH] %s FY%s — computed=%.2f%%, source=%.2f%%, diff=%.2f%%",
                company_id, year, computed, source_opm, diff,
            )
    return computed


def return_on_equity(
    net_profit: Optional[float],
    equity_capital: Optional[float],
    reserves: Optional[float],
) -> Optional[float]:
    """
    ROE = net_profit / (equity_capital + reserves) × 100
    Returns None if equity + reserves ≤ 0.
    """
    if equity_capital is None and reserves is None:
        return None
    total_equity = (equity_capital or 0.0) + (reserves or 0.0)
    if total_equity <= 0:
        return None
    result = _safe_div(net_profit, total_equity)
    return None if result is None else result * 100


def return_on_capital_employed(
    operating_profit: Optional[float],
    other_income: Optional[float],
    interest: Optional[float],
    depreciation: Optional[float],
    equity_capital: Optional[float],
    reserves: Optional[float],
    borrowings: Optional[float],
) -> Optional[float]:
    """
    ROCE = EBIT / (equity + reserves + borrowings) × 100
    EBIT = operating_profit + other_income  (pre-interest, pre-tax proxy).
    Returns None if capital employed ≤ 0.
    """
    ebit = (operating_profit or 0.0) + (other_income or 0.0)
    capital_employed = (equity_capital or 0.0) + (reserves or 0.0) + (borrowings or 0.0)
    if capital_employed <= 0:
        return None
    return (ebit / capital_employed) * 100


def return_on_assets(
    net_profit: Optional[float],
    total_assets: Optional[float],
) -> Optional[float]:
    """
    ROA = net_profit / total_assets × 100
    Returns None if total_assets = 0 or None.
    """
    result = _safe_div(net_profit, total_assets)
    return None if result is None else result * 100


# ===========================================================================
# DAY 09 — LEVERAGE & EFFICIENCY RATIOS
# ===========================================================================

def debt_to_equity(
    borrowings: Optional[float],
    equity_capital: Optional[float],
    reserves: Optional[float],
    broad_sector: str = "",
) -> tuple[Optional[float], bool]:
    """
    D/E = borrowings / (equity_capital + reserves)

    - Returns 0 (not None) when borrowings = 0.
    - Returns (None, False) when equity + reserves ≤ 0.
    - high_leverage_flag = True  when D/E > 5 AND sector is NOT Financials.

    Returns
    -------
    (de_ratio, high_leverage_flag)
    """
    borrowings = borrowings or 0.0
    total_equity = (equity_capital or 0.0) + (reserves or 0.0)

    if borrowings == 0:
        return 0.0, False

    if total_equity <= 0:
        return None, False

    de = borrowings / total_equity
    is_financial = (broad_sector or "").strip().lower() == "financials"
    high_flag = (de > 5) and not is_financial
    return de, high_flag


def interest_coverage_ratio(
    operating_profit: Optional[float],
    other_income: Optional[float],
    interest: Optional[float],
) -> tuple[Optional[float], Optional[str], bool]:
    """
    ICR = (operating_profit + other_income) / interest

    - Returns (None, 'Debt Free', False)  when interest = 0 (debt-free).
    - Returns (value, None, warning_flag)  otherwise.
    - warning_flag = True  when ICR < 1.5.

    Returns
    -------
    (icr_value, icr_label, icr_warning_flag)
    """
    interest = interest or 0.0
    if interest == 0:
        return None, "Debt Free", False

    ebit_plus = (operating_profit or 0.0) + (other_income or 0.0)
    icr = ebit_plus / interest
    warning = icr < 1.5
    return icr, None, warning


def net_debt(
    borrowings: Optional[float],
    investments: Optional[float],
) -> float:
    """
    Net Debt = borrowings − investments
    Uses investments as liquid-asset proxy.
    Negative value = net cash position.
    """
    return (borrowings or 0.0) - (investments or 0.0)


def asset_turnover(
    sales: Optional[float],
    total_assets: Optional[float],
) -> Optional[float]:
    """
    Asset Turnover = sales / total_assets
    Returns None if total_assets = 0 or None.
    """
    return _safe_div(sales, total_assets)


# ===========================================================================
# COMPOSITE — compute all ratios for one (company, year) row
# ===========================================================================

def compute_all_ratios(row: dict) -> dict:
    """
    Accept a dict of raw financials for one (company_id, year).
    Return a flat dict of all computed ratio columns ready for DB insert.
    """
    cid = row.get("company_id", "")
    yr  = row.get("year", 0)
    sector = row.get("broad_sector", "")

    npm  = net_profit_margin(row.get("net_profit"), row.get("sales"))
    opm  = operating_profit_margin(
        row.get("operating_profit"), row.get("sales"),
        source_opm=row.get("opm_percentage"),
        company_id=cid, year=yr,
    )
    roe  = return_on_equity(row.get("net_profit"), row.get("equity_capital"), row.get("reserves"))
    roce = return_on_capital_employed(
        row.get("operating_profit"), row.get("other_income"), row.get("interest"),
        row.get("depreciation"), row.get("equity_capital"), row.get("reserves"),
        row.get("borrowings"),
    )
    roa  = return_on_assets(row.get("net_profit"), row.get("total_assets"))

    de, high_lev = debt_to_equity(
        row.get("borrowings"), row.get("equity_capital"), row.get("reserves"), sector
    )
    icr, icr_label, icr_warn = interest_coverage_ratio(
        row.get("operating_profit"), row.get("other_income"), row.get("interest")
    )
    nd  = net_debt(row.get("borrowings"), row.get("investments"))
    at  = asset_turnover(row.get("sales"), row.get("total_assets"))

    return {
        "net_profit_margin_pct":        npm,
        "operating_profit_margin_pct":  opm,
        "return_on_equity_pct":         roe,
        "return_on_capital_employed":   roce,
        "return_on_assets_pct":         roa,
        "debt_to_equity":               de,
        "high_leverage_flag":           int(high_lev),
        "interest_coverage":            icr,
        "icr_label":                    icr_label,
        "icr_warning_flag":             int(icr_warn),
        "net_debt":                     nd,
        "asset_turnover":               at,
        # Pass-through fields
        "earnings_per_share":           row.get("eps"),
        "book_value_per_share":         row.get("book_value"),
        "dividend_payout_ratio_pct":    row.get("dividend_payout"),
        "total_debt_cr":                row.get("borrowings"),
        "cash_from_operations_cr":      row.get("operating_activity"),
        "capex_cr":                     abs(row.get("investing_activity") or 0),
    }
