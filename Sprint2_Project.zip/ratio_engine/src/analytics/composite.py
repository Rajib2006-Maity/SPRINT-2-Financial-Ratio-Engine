"""
src/analytics/composite.py
===========================
Composite Quality Score for each (company, year).

Combines ROE, ROCE, D/E, ICR, and CFO Quality into a single 0–100 score.
Used in the financial_ratios.composite_quality_score column.
"""

from __future__ import annotations
from typing import Optional


def composite_quality_score(
    roe: Optional[float],
    roce: Optional[float],
    de: Optional[float],
    icr: Optional[float],
    cfo_quality: Optional[float],
    is_financial: bool = False,
) -> Optional[float]:
    """
    Score = weighted average of normalised sub-scores (0–100 each).

    Weights
    -------
    ROE              25%   (higher is better; capped at 40%)
    ROCE             25%   (higher is better; capped at 40%)
    D/E              20%   (lower is better; 0→100, 5→0, capped)
    ICR              15%   (higher is better; >5 = full marks)
    CFO Quality      15%   (ratio; >1 = full marks)

    For Financials sector, D/E sub-score is excluded and weights redistributed.
    """
    scores: list[tuple[float, float]] = []   # (sub_score, weight)

    # --- ROE (0–100, capped at 40%)
    if roe is not None:
        s = min(max(roe / 40.0, 0), 1) * 100
        scores.append((s, 0.25))

    # --- ROCE (0–100, capped at 40%)
    if roce is not None:
        s = min(max(roce / 40.0, 0), 1) * 100
        scores.append((s, 0.25))

    # --- D/E (lower is better; 0 = 100 pts, 5+ = 0 pts) — skipped for Financials
    if de is not None and not is_financial:
        s = max(1 - de / 5.0, 0) * 100
        scores.append((s, 0.20))
    elif de is not None and is_financial:
        pass  # weight redistributed implicitly

    # --- ICR (capped at 5; debt-free = None → treat as max)
    if icr is not None:
        s = min(max(icr / 5.0, 0), 1) * 100
        scores.append((s, 0.15))
    else:
        # Debt-free companies get full ICR score
        scores.append((100.0, 0.15))

    # --- CFO Quality ratio (>1 = full marks)
    if cfo_quality is not None:
        s = min(max(cfo_quality, 0), 1) * 100
        scores.append((s, 0.15))

    if not scores:
        return None

    # Normalise weights to sum to 1
    total_weight = sum(w for _, w in scores)
    score = sum(s * w for s, w in scores) / total_weight
    return round(score, 2)
