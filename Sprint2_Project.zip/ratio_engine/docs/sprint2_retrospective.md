# Sprint 2 Retrospective — Formula Decisions & Edge Case Resolutions

**Epic:** 02 — Financial Ratio Engine  
**Sprint:** 2 (Days 08–14)  
**Author:** Ratio Engine Team  
**Status:** Signed off

---

## 1. Formula Decisions

### 1.1 EBIT Proxy for ROCE

**Decision:** `EBIT = operating_profit + other_income`

**Rationale:** The raw data does not always carry a standalone EBIT field.
`operating_profit` is pre-interest and pre-tax; adding `other_income` brings
it closer to the full earnings-before-interest figure used in textbook ROCE.
This is consistent with how Screener.in and Ticker.finology present ROCE for
Indian companies.

**Alternative considered:** `EBIT = net_profit + interest + tax`
Rejected because tax is not a direct column in the schema; back-computing it
from an implied tax rate introduces more error than using the operating line.

---

### 1.2 ROE Denominator — Average vs. Point-in-Time Equity

**Decision:** Point-in-time equity (`equity_capital + reserves` at year-end).

**Rationale:** We only receive one balance-sheet snapshot per fiscal year.
Using a 2-year average would require lagging data that is not always present
for the earliest year of each company's history.

**Implication:** ROE will be slightly overstated in years of rapid equity
growth (rights issues, large retained earnings). For year-on-year trend
analysis this is acceptable; for absolute benchmarking, flag this to analysts.

---

### 1.3 Debt-to-Equity: 0 vs. None for Zero-Debt Companies

**Decision:** Return `0.0` (not `None`) when `borrowings == 0`.

**Rationale:** `None` in a ratio column implies data unavailability. Zero
borrowings is a meaningful financial state (fully equity-funded). Screeners
filtering `D/E < 0.5` should still include zero-debt companies.

**Edge case:** `interest` is zeroed out in the data pipeline whenever
`borrowings == 0`, preventing the ICR formula from producing an ICR value
when the company has no debt. The `icr_label` column is set to `"Debt Free"`
in this case.

---

### 1.4 CAGR with Negative Base Values

**Decision:** Six discrete flags instead of a single `None`:

| Flag | Start | End | Meaning |
|---|---|---|---|
| `NORMAL` | > 0 | > 0 | Standard computation |
| `DECLINE_TO_LOSS` | > 0 | < 0 | Profit → Loss |
| `TURNAROUND` | < 0 | > 0 | Loss → Profit |
| `BOTH_NEGATIVE` | < 0 | < 0 | Losses both ends |
| `ZERO_BASE` | = 0 | any | Division undefined |
| `INSUFFICIENT` | — | — | Not enough years of data |

**Rationale:** A blanket `None` collapses four economically distinct
situations into one. The flag column allows screeners to surface
turnaround stories (`TURNAROUND`) and filter out noise (`BOTH_NEGATIVE`).

---

### 1.5 CFO Quality Score: 5-Year Rolling Average

**Decision:** Average `CFO / PAT` over the most recent 5 years (or fewer if
data is unavailable). Years where `PAT == 0` are excluded from the average.

**Rationale:** A single year's ratio is noisy — capital expenditure timing,
one-off provisions, or working capital releases all cause large swings.
A 5-year average is the standard period used by quality-factor investors
(e.g., Piotroski F-Score, O'Shaughnessy's What Works on Wall Street).

---

### 1.6 CapEx Proxy: |Investing Activity|

**Decision:** `CapEx = abs(investing_activity)` as a proxy.

**Rationale:** The source data does not separate maintenance capex from
growth capex or financial investments. For non-financial companies,
`investing_activity` is dominated by property, plant, and equipment spend.
For financial companies this proxy is less reliable; the Financials
carve-out note in §2.1 applies.

---

### 1.7 Composite Quality Score Weights

| Component | Weight | Non-Financial | Financial |
|---|---|---|---|
| ROE | 25% | ✓ | ✓ |
| ROCE | 25% | ✓ | ✓ |
| D/E | 20% | ✓ | ✗ (excluded) |
| ICR | 15% | ✓ (Debt Free = 100 pts) | ✓ |
| CFO Quality | 15% | ✓ | ✓ |

Weights are normalised when a component is excluded (e.g., Financial sector
D/E weight is redistributed proportionally across remaining components).

---

## 2. Edge Case Resolutions

### 2.1 Financials Sector Carve-Out (19 companies)

**Issue:** Banks, NBFCs, and insurance companies structurally carry D/E ratios
of 5–15x due to deposit and policy liabilities. The `high_leverage_flag`
would fire for nearly all of them, making the flag meaningless.

**Resolution:**
- `high_leverage_flag` is set to `0` for all Financials sector companies
  regardless of D/E level.
- ROCE benchmark comparison uses sector-relative thresholds for Financials
  (10–15% ROCE is strong for a bank vs. 20–25% for industrials).
- All suppressions are written to `output/ratio_edge_cases.log` with
  category `suppressed_for_sector`.

---

### 2.2 Negative Equity (CO005, FY2010–2014)

**Issue:** `reserves` is negative in early years, making
`equity_capital + reserves ≤ 0`. ROE and D/E are undefined.

**Resolution:**
- ROE returns `None` when `equity + reserves ≤ 0`.
- D/E returns `None` (not `0`) — the company has debt but equity
  denominator is non-positive.
- CAGR for PAT is computed normally if both endpoints are negative
  (`BOTH_NEGATIVE` flag).

---

### 2.3 ROCE vs. Source Pre-Computed Column

**Issue:** The `roce_percentage` column in `companies.xlsx` uses a different
capital-structure definition (some providers capitalise operating leases, others
use only balance-sheet debt). Differences of 5–20% are common.

**Resolution:**
- Anomalies where `|computed - source| > 5%` are logged to
  `ratio_edge_cases.log` with category `version_difference` or
  `formula_discrepancy`.
- The **engine-computed value** is used for all analytics.
- The **source value** is retained in the `financials` table for display
  and transparency.

---

### 2.4 ROE Source Anomaly — Apparent Decimal Format (e.g., TCS = 0.52)

**Issue:** Some source `roe_percentage` values appear to be in decimal
format (0.52 meaning 52%) rather than percentage format.

**Resolution:**
- Any source ROE where `0 < source_roe < 1.0` is flagged as
  `data_source_issue` in the log.
- Engine-computed ROE is used exclusively for analytics.

---

### 2.5 CAGR Windows with Insufficient History

**Issue:** For companies with fewer than `n+1` years of data, the n-year
CAGR window cannot be computed.

**Resolution:** Flag is set to `INSUFFICIENT`, value to `NULL`. This affects:
- All companies for the first 3/5/10 years of their history.
- The screener excludes `NULL` CAGR values by default.

---

### 2.6 Debt-Free Companies with Non-Zero Interest

**Issue:** In raw source data, some companies record small interest charges
even when `borrowings == 0` (e.g., interest on lease liabilities before
IFRS 16 reclassification, or bank charges misclassified as interest).

**Resolution:**
- The data pipeline zeros `interest` when `borrowings == 0` to maintain
  the semantic integrity of the debt-free classification.
- This is logged as a pipeline normalisation, not an anomaly.

---

## 3. Known Limitations & Future Sprint Items

| # | Limitation | Priority |
|---|---|---|
| 1 | CapEx proxy (`|CFI|`) conflates growth capex with financial investments for Financials sector | Sprint 3 — High |
| 2 | ROE uses point-in-time equity; should use 2-year average | Sprint 3 — Medium |
| 3 | No DuPont decomposition (NPM × Asset Turnover × Leverage = ROE) | Sprint 3 — Medium |
| 4 | CAGR for EPS not adjusted for share splits / buybacks | Sprint 4 — Low |
| 5 | Composite quality score weights are heuristic; need backtesting against actual returns | Sprint 4 — Medium |

---

## 4. Sprint 2 Definition of Done — Sign-Off

| Check | Result |
|---|---|
| `SELECT COUNT(*) FROM financial_ratios` ≥ 1,100 | ✅ 1,380 rows |
| All 14 KPI columns populated | ✅ 17 columns, 0 null-only |
| 20 KPI unit tests, 0 failures | ✅ 52 tests, 0 failures |
| ROE & Revenue CAGR spot-check within 0.1% | ✅ 3 companies, diff < 0.0001% |
| `ratio_edge_cases.log` with documented anomalies | ✅ All entries categorised |
| Sprint review meeting | ✅ Completed |

**Signed off by:** Team Lead  
**Date:** Sprint Day 14
