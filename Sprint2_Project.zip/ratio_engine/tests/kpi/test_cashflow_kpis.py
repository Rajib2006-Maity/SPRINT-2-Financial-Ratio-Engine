"""
tests/kpi/test_cashflow_kpis.py
================================
Day 11 — Cash flow KPI unit tests

Tests:
  1.  FCF — positive CFO + negative CFI (normal reinvestor)
  2.  FCF — both negative is allowed
  3.  CFO Quality — >1.0 → High Quality label
  4.  CFO Quality — 0.5–1.0 → Moderate
  5.  CFO Quality — <0.5 → Accrual Risk
  6.  CFO Quality — PAT = 0 skips pair → None if all pairs invalid
  7.  CapEx Intensity — <3% → Asset Light
  8.  CapEx Intensity — 3–8% → Moderate
  9.  CapEx Intensity — >8% → Capital Intensive
  10. CapEx Intensity — zero sales → None
  11. FCF Conversion — normal case
  12. FCF Conversion — zero operating_profit → None
  13. Capital allocation (+,-,-) → Reinvestor
  14. Capital allocation (-,-,+) → Growth Funded by Debt
  15. Capital allocation (+,-,-) high CFO/PAT → Shareholder Returns
  16. Capital allocation (-,+,+) → Distress Signal
  17. Capital allocation (+,+,+) → Cash Accumulator
  18. compute_cashflow_kpis — returns required keys
"""

import pytest
from src.analytics.cashflow_kpis import (
    free_cash_flow,
    cfo_quality_score,
    capex_intensity,
    fcf_conversion_rate,
    capital_allocation_pattern,
    compute_cashflow_kpis,
)


# ------------------------------------------------------------------ #
# FCF
# ------------------------------------------------------------------ #
def test_fcf_normal():
    assert free_cash_flow(operating_activity=500, investing_activity=-200) == pytest.approx(300)


def test_fcf_both_negative_allowed():
    result = free_cash_flow(operating_activity=-100, investing_activity=-400)
    assert result == pytest.approx(-500), "Negative FCF is valid"


# ------------------------------------------------------------------ #
# CFO Quality Score
# ------------------------------------------------------------------ #
def test_cfo_quality_high():
    pairs = [(1200, 800), (1100, 700), (1300, 900)]
    score, label = cfo_quality_score(pairs)
    assert label == "High Quality"
    assert score > 1.0


def test_cfo_quality_moderate():
    pairs = [(700, 1000), (600, 1000), (800, 1000)]   # avg ratio ~0.7
    score, label = cfo_quality_score(pairs)
    assert label == "Moderate"
    assert 0.5 <= score <= 1.0


def test_cfo_quality_accrual_risk():
    pairs = [(200, 1000), (150, 1000), (100, 1000)]   # avg ~0.15
    score, label = cfo_quality_score(pairs)
    assert label == "Accrual Risk"
    assert score < 0.5


def test_cfo_quality_zero_pat_skipped():
    pairs = [(500, 0), (500, 0)]   # all PAT=0 → no valid pairs
    score, label = cfo_quality_score(pairs)
    assert score is None
    assert label is None


# ------------------------------------------------------------------ #
# CapEx Intensity
# ------------------------------------------------------------------ #
def test_capex_intensity_asset_light():
    pct, label = capex_intensity(investing_activity=-200, sales=10_000)  # 2%
    assert label == "Asset Light"
    assert pct == pytest.approx(2.0, rel=1e-4)


def test_capex_intensity_moderate():
    pct, label = capex_intensity(investing_activity=-500, sales=10_000)  # 5%
    assert label == "Moderate"


def test_capex_intensity_capital_intensive():
    pct, label = capex_intensity(investing_activity=-1000, sales=10_000)  # 10%
    assert label == "Capital Intensive"
    assert pct > 8.0


def test_capex_intensity_zero_sales_returns_none():
    pct, label = capex_intensity(investing_activity=-500, sales=0)
    assert pct is None
    assert label is None


# ------------------------------------------------------------------ #
# FCF Conversion Rate
# ------------------------------------------------------------------ #
def test_fcf_conversion_normal():
    rate = fcf_conversion_rate(fcf=300, operating_profit=600)
    assert rate == pytest.approx(50.0, rel=1e-6)


def test_fcf_conversion_zero_op_returns_none():
    assert fcf_conversion_rate(fcf=300, operating_profit=0) is None


# ------------------------------------------------------------------ #
# Capital Allocation Patterns
# ------------------------------------------------------------------ #
def test_pattern_reinvestor():
    cs, ci, cf, label = capital_allocation_pattern(cfo=500, cfi=-300, cff=-100)
    assert label == "Reinvestor"
    assert cs == "+" and ci == "-" and cf == "-"


def test_pattern_growth_funded_by_debt():
    cs, ci, cf, label = capital_allocation_pattern(cfo=-200, cfi=-300, cff=600)
    assert label == "Growth Funded by Debt"


def test_pattern_shareholder_returns():
    # (+,-,-) with high CFO/PAT → Shareholder Returns
    cs, ci, cf, label = capital_allocation_pattern(
        cfo=1500, cfi=-300, cff=-200, cfo_pat_ratio=2.0
    )
    assert label == "Shareholder Returns"


def test_pattern_distress_signal():
    cs, ci, cf, label = capital_allocation_pattern(cfo=-300, cfi=200, cff=500)
    assert label == "Distress Signal"


def test_pattern_cash_accumulator():
    cs, ci, cf, label = capital_allocation_pattern(cfo=400, cfi=200, cff=100)
    assert label == "Cash Accumulator"


# ------------------------------------------------------------------ #
# compute_cashflow_kpis — integration smoke
# ------------------------------------------------------------------ #
def test_compute_cashflow_kpis_returns_required_keys():
    row = {
        "operating_activity":  800,
        "investing_activity": -300,
        "financing_activity": -200,
        "net_profit":          600,
        "sales":             10_000,
        "operating_profit":    1_200,
    }
    result = compute_cashflow_kpis(row)

    required = [
        "free_cash_flow_cr",
        "cfo_quality_score", "cfo_quality_label",
        "capex_intensity_pct", "capex_intensity_label",
        "fcf_conversion_rate",
        "capital_allocation_pattern",
        "_cfo_sign", "_cfi_sign", "_cff_sign",
    ]
    for key in required:
        assert key in result, f"Missing key: {key}"

    assert result["free_cash_flow_cr"] == pytest.approx(500.0)
    assert result["_cfo_sign"] == "+"
    assert result["_cfi_sign"] == "-"
    assert result["capital_allocation_pattern"] in (
        "Reinvestor", "Shareholder Returns"
    )
