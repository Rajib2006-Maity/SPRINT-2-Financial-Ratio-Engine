"""
tests/kpi/test_leverage_ratios.py
===================================
Day 09 — 8 unit tests

Tests:
  1.  D/E — normal case
  2.  D/E — zero borrowings → 0.0 (not None)
  3.  D/E — negative equity → None
  4.  D/E high leverage flag fires for non-financials (D/E > 5)
  5.  D/E high leverage flag suppressed for Financials sector
  6.  ICR — interest = 0 → (None, 'Debt Free', False)
  7.  ICR — normal case
  8.  ICR < 1.5 → warning flag True
"""

import pytest
from src.analytics.ratios import (
    debt_to_equity,
    interest_coverage_ratio,
    net_debt,
    asset_turnover,
)


# ------------------------------------------------------------------ #
# 1. D/E — normal case
# ------------------------------------------------------------------ #
def test_de_normal():
    de, flag = debt_to_equity(borrowings=3000, equity_capital=200, reserves=800)
    assert de == pytest.approx(3.0, rel=1e-6)
    assert flag is False


# ------------------------------------------------------------------ #
# 2. D/E — zero borrowings → returns 0.0, not None
# ------------------------------------------------------------------ #
def test_de_debt_free_returns_zero():
    de, flag = debt_to_equity(borrowings=0, equity_capital=200, reserves=800)
    assert de == 0.0, "D/E should be 0.0 (not None) when debt-free"
    assert flag is False


# ------------------------------------------------------------------ #
# 3. D/E — negative equity → None
# ------------------------------------------------------------------ #
def test_de_negative_equity_returns_none():
    de, flag = debt_to_equity(borrowings=500, equity_capital=50, reserves=-500)
    assert de is None
    assert flag is False


# ------------------------------------------------------------------ #
# 4. High leverage flag fires when D/E > 5 and sector != Financials
# ------------------------------------------------------------------ #
def test_de_high_leverage_flag_non_financial():
    de, flag = debt_to_equity(borrowings=6000, equity_capital=100, reserves=900, broad_sector="Industrials")
    assert de == pytest.approx(6.0, rel=1e-6)
    assert flag is True, "Flag should be True for D/E > 5 outside Financials"


# ------------------------------------------------------------------ #
# 5. High leverage flag suppressed for Financials sector
# ------------------------------------------------------------------ #
def test_de_high_leverage_flag_suppressed_for_financials():
    de, flag = debt_to_equity(borrowings=6000, equity_capital=100, reserves=900, broad_sector="Financials")
    assert de == pytest.approx(6.0, rel=1e-6)
    assert flag is False, "Flag should be False for Financials even with D/E > 5"


# ------------------------------------------------------------------ #
# 6. ICR — interest = 0 → label = 'Debt Free', value = None
# ------------------------------------------------------------------ #
def test_icr_zero_interest_returns_debt_free():
    icr, label, warning = interest_coverage_ratio(
        operating_profit=500, other_income=50, interest=0
    )
    assert icr is None, "ICR value should be None when debt-free"
    assert label == "Debt Free"
    assert warning is False


# ------------------------------------------------------------------ #
# 7. ICR — normal case
# ------------------------------------------------------------------ #
def test_icr_normal():
    icr, label, warning = interest_coverage_ratio(
        operating_profit=500, other_income=100, interest=150
    )
    # (500 + 100) / 150 = 4.0
    assert icr == pytest.approx(4.0, rel=1e-6)
    assert label is None
    assert warning is False


# ------------------------------------------------------------------ #
# 8. ICR < 1.5 → warning flag True
# ------------------------------------------------------------------ #
def test_icr_low_coverage_sets_warning_flag():
    icr, label, warning = interest_coverage_ratio(
        operating_profit=100, other_income=0, interest=200
    )
    # ICR = 0.5 < 1.5
    assert icr == pytest.approx(0.5, rel=1e-6)
    assert warning is True, "Warning flag should be True when ICR < 1.5"


# ------------------------------------------------------------------ #
# Bonus: net_debt and asset_turnover smoke tests
# ------------------------------------------------------------------ #
def test_net_debt_calculation():
    nd = net_debt(borrowings=5000, investments=2000)
    assert nd == pytest.approx(3000.0)


def test_asset_turnover_zero_assets_returns_none():
    assert asset_turnover(sales=1000, total_assets=0) is None


def test_asset_turnover_normal():
    at = asset_turnover(sales=2000, total_assets=4000)
    assert at == pytest.approx(0.5, rel=1e-6)
