"""
tests/kpi/test_cagr.py
=======================
Day 10 — 10 unit tests

Tests:
  1.  Normal CAGR — both endpoints positive
  2.  CAGR formula precision (known exact value)
  3.  TURNAROUND flag — start < 0, end > 0
  4.  DECLINE_TO_LOSS flag — start > 0, end < 0
  5.  BOTH_NEGATIVE flag — both endpoints negative
  6.  ZERO_BASE flag — start = 0
  7.  INSUFFICIENT flag — end_year not in series
  8.  INSUFFICIENT flag — start_year not in series (gap)
  9.  Negative n → INSUFFICIENT
  10. compute_cagr_for_year produces all 9 key columns
"""

import math
import pytest
from src.analytics.cagr import cagr, compute_cagr_for_year, build_series


# ------------------------------------------------------------------ #
# 1. Normal CAGR — positive → positive
# ------------------------------------------------------------------ #
def test_cagr_normal_positive():
    value, flag = cagr(start=1000, end=1610.51, n=5)
    assert flag == "NORMAL"
    assert value == pytest.approx(10.0, abs=0.01), "Should be ~10% CAGR"


# ------------------------------------------------------------------ #
# 2. Formula precision: 100 → 146.41 over 4 years = 10% exactly
# ------------------------------------------------------------------ #
def test_cagr_exact_formula():
    end = 100 * (1.10 ** 4)          # 146.41
    value, flag = cagr(start=100, end=end, n=4)
    assert flag == "NORMAL"
    assert value == pytest.approx(10.0, rel=1e-6)


# ------------------------------------------------------------------ #
# 3. TURNAROUND — start negative, end positive
# ------------------------------------------------------------------ #
def test_cagr_turnaround_flag():
    value, flag = cagr(start=-500, end=300, n=5)
    assert value is None
    assert flag == "TURNAROUND"


# ------------------------------------------------------------------ #
# 4. DECLINE_TO_LOSS — start positive, end negative
# ------------------------------------------------------------------ #
def test_cagr_decline_to_loss_flag():
    value, flag = cagr(start=800, end=-200, n=3)
    assert value is None
    assert flag == "DECLINE_TO_LOSS"


# ------------------------------------------------------------------ #
# 5. BOTH_NEGATIVE — both endpoints negative
# ------------------------------------------------------------------ #
def test_cagr_both_negative_flag():
    value, flag = cagr(start=-300, end=-150, n=5)
    assert value is None
    assert flag == "BOTH_NEGATIVE"


# ------------------------------------------------------------------ #
# 6. ZERO_BASE — start = 0
# ------------------------------------------------------------------ #
def test_cagr_zero_base_flag():
    value, flag = cagr(start=0, end=500, n=5)
    assert value is None
    assert flag == "ZERO_BASE"


# ------------------------------------------------------------------ #
# 7. INSUFFICIENT — end_year not present in series
# ------------------------------------------------------------------ #
def test_cagr_insufficient_missing_end():
    value, flag = cagr(start=None, end=500, n=5)
    assert value is None
    assert flag == "INSUFFICIENT"


# ------------------------------------------------------------------ #
# 8. INSUFFICIENT — start_year gap (build_series + window)
# ------------------------------------------------------------------ #
def test_cagr_insufficient_gap_in_series():
    from src.analytics.cagr import _window_values
    series = {2015: 100, 2016: 110, 2017: 120}   # 2012 missing
    sv, ev, n = _window_values(series, end_year=2017, n=5)
    assert n == 0, "Should return n=0 when start year is absent"


# ------------------------------------------------------------------ #
# 9. Negative n → INSUFFICIENT
# ------------------------------------------------------------------ #
def test_cagr_negative_n_returns_insufficient():
    value, flag = cagr(start=100, end=200, n=-3)
    assert value is None
    assert flag == "INSUFFICIENT"


# ------------------------------------------------------------------ #
# 10. compute_cagr_for_year — returns all 9 primary columns
# ------------------------------------------------------------------ #
def test_compute_cagr_for_year_all_columns():
    years = list(range(2010, 2025))
    revenue = {y: 1000 * (1.10 ** (y - 2010)) for y in years}
    pat     = {y: 100  * (1.08 ** (y - 2010)) for y in years}
    eps     = {y: 10   * (1.07 ** (y - 2010)) for y in years}

    result = compute_cagr_for_year(revenue, pat, eps, end_year=2024)

    expected_keys = [
        "revenue_cagr_3yr", "revenue_cagr_3yr_flag",
        "revenue_cagr_5yr", "revenue_cagr_5yr_flag",
        "revenue_cagr_10yr", "revenue_cagr_10yr_flag",
        "pat_cagr_5yr", "pat_cagr_5yr_flag",
        "eps_cagr_5yr", "eps_cagr_5yr_flag",
    ]
    for key in expected_keys:
        assert key in result, f"Missing column: {key}"

    # All computable windows should be NORMAL with positive values
    assert result["revenue_cagr_5yr_flag"] == "NORMAL"
    assert result["revenue_cagr_5yr"] == pytest.approx(10.0, rel=1e-3)
    assert result["pat_cagr_5yr"] == pytest.approx(8.0, rel=1e-3)
    assert result["eps_cagr_5yr"] == pytest.approx(7.0, rel=1e-3)


# ------------------------------------------------------------------ #
# Bonus: build_series helper
# ------------------------------------------------------------------ #
def test_build_series_maps_years_to_values():
    rows = [
        {"year": 2020, "sales": 1000},
        {"year": 2021, "sales": 1200},
        {"year": 2022, "sales": None},
    ]
    series = build_series(rows, "sales")
    assert series == {2020: 1000, 2021: 1200, 2022: None}
