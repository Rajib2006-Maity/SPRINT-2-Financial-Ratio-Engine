"""
tests/kpi/test_profitability_ratios.py
=======================================
Day 08 — 8 unit tests

Tests:
  1. Net profit margin — normal case
  2. Net profit margin — zero sales → None
  3. Operating profit margin — normal case
  4. OPM cross-check mismatch triggers log warning
  5. ROE — normal case
  6. ROE — negative equity → None
  7. ROCE — normal case
  8. ROA — zero total_assets → None
"""

import logging
import pytest
from src.analytics.ratios import (
    net_profit_margin,
    operating_profit_margin,
    return_on_equity,
    return_on_capital_employed,
    return_on_assets,
)


# ------------------------------------------------------------------ #
# 1. Net Profit Margin — normal
# ------------------------------------------------------------------ #
def test_npm_normal():
    result = net_profit_margin(net_profit=200, sales=1000)
    assert result == pytest.approx(20.0, rel=1e-6), "NPM should be 20%"


# ------------------------------------------------------------------ #
# 2. Net Profit Margin — zero sales → None
# ------------------------------------------------------------------ #
def test_npm_zero_sales_returns_none():
    assert net_profit_margin(net_profit=100, sales=0) is None


def test_npm_none_sales_returns_none():
    assert net_profit_margin(net_profit=100, sales=None) is None


# ------------------------------------------------------------------ #
# 3. OPM — normal case
# ------------------------------------------------------------------ #
def test_opm_normal():
    result = operating_profit_margin(operating_profit=150, sales=1000)
    assert result == pytest.approx(15.0, rel=1e-6)


# ------------------------------------------------------------------ #
# 4. OPM cross-check mismatch → log warning (diff > 1%)
# ------------------------------------------------------------------ #
def test_opm_crosscheck_mismatch_logs(caplog):
    with caplog.at_level(logging.WARNING, logger="src.analytics.ratios"):
        operating_profit_margin(
            operating_profit=200, sales=1000,
            source_opm=17.5,  # computed=20%, diff=2.5% → mismatch
            company_id="CO001", year=2023,
        )
    assert any("OPM MISMATCH" in r.message for r in caplog.records), \
        "Expected OPM MISMATCH warning when diff > 1%"


def test_opm_crosscheck_no_warning_when_close(caplog):
    with caplog.at_level(logging.WARNING, logger="src.analytics.ratios"):
        operating_profit_margin(
            operating_profit=200, sales=1000,
            source_opm=19.8,  # diff = 0.2% → OK
            company_id="CO001", year=2023,
        )
    assert not any("OPM MISMATCH" in r.message for r in caplog.records)


# ------------------------------------------------------------------ #
# 5. ROE — normal
# ------------------------------------------------------------------ #
def test_roe_normal():
    roe = return_on_equity(net_profit=300, equity_capital=100, reserves=2900)
    assert roe == pytest.approx(10.0, rel=1e-6), "ROE = 300/3000 × 100 = 10%"


# ------------------------------------------------------------------ #
# 6. ROE — negative equity → None
# ------------------------------------------------------------------ #
def test_roe_negative_equity_returns_none():
    # equity + reserves ≤ 0
    assert return_on_equity(net_profit=100, equity_capital=50, reserves=-200) is None


def test_roe_zero_equity_returns_none():
    assert return_on_equity(net_profit=100, equity_capital=0, reserves=0) is None


# ------------------------------------------------------------------ #
# 7. ROCE — normal
# ------------------------------------------------------------------ #
def test_roce_normal():
    roce = return_on_capital_employed(
        operating_profit=500, other_income=50, interest=100,
        depreciation=80, equity_capital=200, reserves=1800, borrowings=1000,
    )
    # EBIT = 550, CE = 3000 → 550/3000 × 100 = 18.33%
    assert roce == pytest.approx(18.333, rel=1e-3)


# ------------------------------------------------------------------ #
# 8. ROA — zero total_assets → None
# ------------------------------------------------------------------ #
def test_roa_zero_assets_returns_none():
    assert return_on_assets(net_profit=100, total_assets=0) is None


def test_roa_normal():
    roa = return_on_assets(net_profit=200, total_assets=4000)
    assert roa == pytest.approx(5.0, rel=1e-6)
