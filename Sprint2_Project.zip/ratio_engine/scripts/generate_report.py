"""
scripts/generate_report.py
===========================
Day 14 — Sprint 2 HTML Demo Report

Generates output/sprint2_report.html — a self-contained HTML file showing:
  - Sprint summary metrics
  - KPI coverage table
  - Top 20 companies by composite quality score
  - CAGR flag distribution chart
  - Capital allocation pattern breakdown
  - Edge case summary
  - Sector heatmap of median ROE

Usage:
    python scripts/generate_report.py [--db data/financials.db]
"""

from __future__ import annotations
import argparse
import sys
from pathlib import Path
from datetime import datetime

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.db.schema import get_connection, DB_PATH

OUTPUT_HTML = ROOT / "output" / "sprint2_report.html"


def q(conn, sql: str, params=()) -> list:
    conn.row_factory = None
    return conn.execute(sql, params).fetchall()


def build_report(db_path: Path) -> str:
    conn = get_connection(db_path)
    conn.row_factory = None

    # ── Core metrics ──────────────────────────────────────────────────────────
    total_rows    = q(conn, "SELECT COUNT(*) FROM financial_ratios")[0][0]
    total_cos     = q(conn, "SELECT COUNT(DISTINCT company_id) FROM financial_ratios")[0][0]
    year_range    = q(conn, "SELECT MIN(year), MAX(year) FROM financial_ratios")[0]
    screener_hit  = q(conn, "SELECT COUNT(DISTINCT company_id) FROM financial_ratios WHERE return_on_equity_pct > 15 AND debt_to_equity < 1")[0][0]
    debt_free_cos = q(conn, "SELECT COUNT(DISTINCT company_id) FROM financial_ratios WHERE icr_label = 'Debt Free'")[0][0]
    high_lev      = q(conn, "SELECT COUNT(DISTINCT company_id) FROM financial_ratios WHERE high_leverage_flag = 1")[0][0]
    icr_warn      = q(conn, "SELECT COUNT(*) FROM financial_ratios WHERE icr_warning_flag = 1")[0][0]

    # ── Top 20 companies (latest year) ────────────────────────────────────────
    latest_year = q(conn, "SELECT MAX(year) FROM financial_ratios")[0][0]
    top20 = q(conn, f"""
        SELECT r.company_id, c.broad_sector,
               r.net_profit_margin_pct, r.return_on_equity_pct,
               r.return_on_capital_employed, r.debt_to_equity,
               COALESCE(r.icr_label, ROUND(r.interest_coverage,1)) as icr_display,
               r.revenue_cagr_5yr, r.revenue_cagr_5yr_flag,
               r.capex_intensity_label, r.capital_allocation_pattern,
               r.composite_quality_score
        FROM financial_ratios r
        JOIN companies c ON c.company_id = r.company_id
        WHERE r.year = {latest_year}
        ORDER BY r.composite_quality_score DESC NULLS LAST
        LIMIT 20
    """)

    # ── CAGR flag distribution ────────────────────────────────────────────────
    cagr_flags = q(conn, """
        SELECT revenue_cagr_5yr_flag, COUNT(*) c
        FROM financial_ratios
        WHERE revenue_cagr_5yr_flag IS NOT NULL
        GROUP BY revenue_cagr_5yr_flag ORDER BY c DESC
    """)

    pat_flags = q(conn, """
        SELECT pat_cagr_5yr_flag, COUNT(*) c
        FROM financial_ratios
        WHERE pat_cagr_5yr_flag IS NOT NULL
        GROUP BY pat_cagr_5yr_flag ORDER BY c DESC
    """)

    # ── Capital allocation patterns ───────────────────────────────────────────
    patterns = q(conn, """
        SELECT capital_allocation_pattern, COUNT(*) c
        FROM financial_ratios
        WHERE capital_allocation_pattern IS NOT NULL
        GROUP BY capital_allocation_pattern ORDER BY c DESC
    """)

    # ── Sector median ROE ─────────────────────────────────────────────────────
    sector_roe = q(conn, f"""
        SELECT c.broad_sector,
               ROUND(AVG(r.return_on_equity_pct), 1) avg_roe,
               ROUND(AVG(r.return_on_capital_employed), 1) avg_roce,
               ROUND(AVG(r.debt_to_equity), 2) avg_de,
               COUNT(DISTINCT r.company_id) n_cos
        FROM financial_ratios r
        JOIN companies c ON c.company_id = r.company_id
        WHERE r.year = {latest_year} AND r.return_on_equity_pct IS NOT NULL
        GROUP BY c.broad_sector
        ORDER BY avg_roe DESC
    """)

    # ── CFO quality distribution ──────────────────────────────────────────────
    cfo_dist = q(conn, """
        SELECT cfo_quality_label, COUNT(*) c
        FROM financial_ratios
        WHERE cfo_quality_label IS NOT NULL
        GROUP BY cfo_quality_label ORDER BY c DESC
    """)

    # ── CapEx intensity distribution ──────────────────────────────────────────
    capex_dist = q(conn, """
        SELECT capex_intensity_label, COUNT(*) c
        FROM financial_ratios
        WHERE capex_intensity_label IS NOT NULL
        GROUP BY capex_intensity_label ORDER BY c DESC
    """)

    conn.close()

    # ── HTML helpers ──────────────────────────────────────────────────────────
    def fmt(v, decimals=1):
        if v is None: return '<span class="na">—</span>'
        try:
            return f"{float(v):.{decimals}f}"
        except (TypeError, ValueError):
            return str(v)

    def badge(v, label=None):
        text = label or str(v)
        colours = {
            "NORMAL": "green", "INSUFFICIENT": "grey",
            "TURNAROUND": "blue", "DECLINE_TO_LOSS": "red",
            "BOTH_NEGATIVE": "orange", "ZERO_BASE": "purple",
            "High Quality": "green", "Moderate": "amber", "Accrual Risk": "red",
            "Asset Light": "green", "Capital Intensive": "red",
            "Reinvestor": "green", "Shareholder Returns": "teal",
            "Growth Funded by Debt": "orange", "Distress Signal": "red",
            "Cash Accumulator": "blue", "Pre-Revenue": "grey", "Mixed": "slate",
            "Financials": "blue", "Technology": "purple", "Consumer": "teal",
            "Industrials": "slate", "Healthcare": "green",
            "Energy": "amber", "Materials": "orange",
        }
        colour = colours.get(text, "slate")
        return f'<span class="badge {colour}">{text}</span>'

    def bar_chart(data, label_key=0, value_key=1, title="", colour="blue"):
        if not data: return ""
        max_v = max(r[value_key] for r in data) or 1
        rows_html = ""
        for r in data:
            lbl = str(r[label_key]) if r[label_key] else "None"
            val = r[value_key]
            pct = val / max_v * 100
            rows_html += f"""
            <div class="bar-row">
                <div class="bar-label">{lbl}</div>
                <div class="bar-track">
                    <div class="bar-fill {colour}" style="width:{pct:.1f}%"></div>
                </div>
                <div class="bar-value">{val:,}</div>
            </div>"""
        return f'<div class="chart"><div class="chart-title">{title}</div>{rows_html}</div>'

    # ── Top 20 table rows ─────────────────────────────────────────────────────
    table_rows = ""
    for i, r in enumerate(top20, 1):
        score = r[11]
        score_class = "score-high" if score and score >= 75 else ("score-mid" if score and score >= 50 else "score-low")
        cagr_flag = r[8]
        cagr_val  = fmt(r[7])
        cagr_cell = f"{cagr_val}% {badge(cagr_flag)}" if cagr_flag else cagr_val
        table_rows += f"""
        <tr>
            <td class="rank">{i}</td>
            <td class="mono bold">{r[0]}</td>
            <td>{badge(r[1])}</td>
            <td class="num">{fmt(r[2])}%</td>
            <td class="num">{fmt(r[3])}%</td>
            <td class="num">{fmt(r[4])}%</td>
            <td class="num">{fmt(r[5], 2)}</td>
            <td class="num">{r[6]}</td>
            <td class="num">{cagr_cell}</td>
            <td>{badge(r[9]) if r[9] else '—'}</td>
            <td>{badge(r[10]) if r[10] else '—'}</td>
            <td class="{score_class}">{fmt(score)}</td>
        </tr>"""

    # ── Sector table rows ─────────────────────────────────────────────────────
    sector_rows = ""
    for r in sector_roe:
        roe = r[1] or 0
        heat = "heat-high" if roe >= 20 else ("heat-mid" if roe >= 10 else "heat-low")
        sector_rows += f"""
        <tr>
            <td>{badge(r[0])}</td>
            <td class="num {heat}">{fmt(r[1])}%</td>
            <td class="num">{fmt(r[2])}%</td>
            <td class="num">{fmt(r[3], 2)}</td>
            <td class="num">{r[4]}</td>
        </tr>"""

    now = datetime.now().strftime("%d %b %Y %H:%M")

    # ── Full HTML ─────────────────────────────────────────────────────────────
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sprint 2 — Financial Ratio Engine Report</title>
<style>
  :root {{
    --bg: #0f1117; --surface: #1a1d27; --surface2: #222536;
    --border: #2e3348; --text: #e2e8f0; --muted: #8892a4;
    --green: #22c55e; --red: #ef4444; --blue: #3b82f6;
    --amber: #f59e0b; --purple: #a855f7; --teal: #14b8a6;
    --orange: #f97316; --slate: #64748b; --grey: #6b7280;
  }}
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ background: var(--bg); color: var(--text); font-family: 'Inter', system-ui, sans-serif;
         font-size: 13px; line-height: 1.6; padding: 0; }}
  .header {{ background: linear-gradient(135deg, #1a1d27 0%, #0f1117 100%);
             border-bottom: 1px solid var(--border); padding: 32px 40px 24px; }}
  .header h1 {{ font-size: 22px; font-weight: 700; color: #fff; letter-spacing: -0.3px; }}
  .header .sub {{ color: var(--muted); font-size: 12px; margin-top: 4px; }}
  .main {{ padding: 32px 40px; max-width: 1400px; margin: 0 auto; }}
  .section {{ margin-bottom: 36px; }}
  .section-title {{ font-size: 11px; font-weight: 700; text-transform: uppercase;
                    letter-spacing: 1.2px; color: var(--muted); margin-bottom: 14px;
                    padding-bottom: 8px; border-bottom: 1px solid var(--border); }}
  .kpi-grid {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(170px, 1fr)); gap: 12px; }}
  .kpi-card {{ background: var(--surface); border: 1px solid var(--border); border-radius: 8px;
               padding: 16px; }}
  .kpi-card .val {{ font-size: 26px; font-weight: 700; color: #fff; line-height: 1.1; }}
  .kpi-card .lbl {{ font-size: 11px; color: var(--muted); margin-top: 4px; }}
  .kpi-card .val.green {{ color: var(--green); }}
  .kpi-card .val.blue  {{ color: var(--blue); }}
  .kpi-card .val.amber {{ color: var(--amber); }}
  .kpi-card .val.red   {{ color: var(--red); }}
  table {{ width: 100%; border-collapse: collapse; background: var(--surface);
           border: 1px solid var(--border); border-radius: 8px; overflow: hidden; }}
  th {{ background: var(--surface2); color: var(--muted); font-size: 10px; font-weight: 600;
        text-transform: uppercase; letter-spacing: 0.8px; padding: 10px 12px; text-align: left;
        border-bottom: 1px solid var(--border); }}
  td {{ padding: 9px 12px; border-bottom: 1px solid var(--border); vertical-align: middle; }}
  tr:last-child td {{ border-bottom: none; }}
  tr:hover td {{ background: var(--surface2); }}
  .num {{ text-align: right; font-variant-numeric: tabular-nums; font-family: 'JetBrains Mono', monospace; }}
  .mono {{ font-family: 'JetBrains Mono', monospace; }}
  .bold {{ font-weight: 600; }}
  .rank {{ color: var(--muted); font-size: 11px; width: 28px; }}
  .na {{ color: var(--muted); }}
  .badge {{ display: inline-block; padding: 2px 7px; border-radius: 4px; font-size: 10px;
            font-weight: 600; letter-spacing: 0.3px; white-space: nowrap; }}
  .badge.green  {{ background: #14532d; color: #86efac; }}
  .badge.red    {{ background: #450a0a; color: #fca5a5; }}
  .badge.blue   {{ background: #172554; color: #93c5fd; }}
  .badge.amber  {{ background: #451a03; color: #fcd34d; }}
  .badge.purple {{ background: #2e1065; color: #d8b4fe; }}
  .badge.teal   {{ background: #042f2e; color: #5eead4; }}
  .badge.orange {{ background: #431407; color: #fdba74; }}
  .badge.slate  {{ background: #1e293b; color: #94a3b8; }}
  .badge.grey   {{ background: #1f2937; color: #9ca3af; }}
  .score-high {{ color: var(--green); font-weight: 700; text-align: right;
                 font-family: monospace; }}
  .score-mid  {{ color: var(--amber); font-weight: 600; text-align: right;
                 font-family: monospace; }}
  .score-low  {{ color: var(--red);   font-weight: 600; text-align: right;
                 font-family: monospace; }}
  .heat-high {{ color: var(--green); font-weight: 600; }}
  .heat-mid  {{ color: var(--amber); }}
  .heat-low  {{ color: var(--red); }}
  .two-col {{ display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }}
  .three-col {{ display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px; }}
  @media(max-width: 900px) {{ .two-col, .three-col {{ grid-template-columns: 1fr; }} }}
  .chart {{ background: var(--surface); border: 1px solid var(--border); border-radius: 8px; padding: 16px; }}
  .chart-title {{ font-size: 11px; font-weight: 600; color: var(--muted); text-transform: uppercase;
                  letter-spacing: 0.8px; margin-bottom: 14px; }}
  .bar-row {{ display: flex; align-items: center; gap: 10px; margin-bottom: 8px; }}
  .bar-label {{ width: 170px; font-size: 11px; color: var(--text); white-space: nowrap;
                overflow: hidden; text-overflow: ellipsis; }}
  .bar-track {{ flex: 1; height: 8px; background: var(--border); border-radius: 4px; overflow: hidden; }}
  .bar-fill  {{ height: 100%; border-radius: 4px; }}
  .bar-fill.blue   {{ background: var(--blue); }}
  .bar-fill.green  {{ background: var(--green); }}
  .bar-fill.purple {{ background: var(--purple); }}
  .bar-fill.amber  {{ background: var(--amber); }}
  .bar-value {{ width: 45px; text-align: right; font-size: 11px; color: var(--muted);
                font-family: monospace; }}
  .footer {{ margin-top: 48px; padding: 20px 40px; border-top: 1px solid var(--border);
             color: var(--muted); font-size: 11px; display: flex; justify-content: space-between; }}
  .pass-pill {{ display: inline-block; background: #14532d; color: #86efac;
                padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight: 700; }}
</style>
</head>
<body>

<div class="header">
  <h1>Sprint 2 — Financial Ratio Engine</h1>
  <div class="sub">Epic 02 · Days 08–14 · Generated {now}</div>
</div>

<div class="main">

  <!-- ── KPI Banner ────────────────────────────────────────────── -->
  <div class="section">
    <div class="section-title">Sprint 2 Exit Criteria</div>
    <div class="kpi-grid">
      <div class="kpi-card">
        <div class="val green">{total_rows:,}</div>
        <div class="lbl">financial_ratios rows<br>(need ≥ 1,100) <span class="pass-pill">✓ PASS</span></div>
      </div>
      <div class="kpi-card">
        <div class="val blue">{total_cos}</div>
        <div class="lbl">companies processed</div>
      </div>
      <div class="kpi-card">
        <div class="val">{year_range[0]}–{year_range[1]}</div>
        <div class="lbl">fiscal year range</div>
      </div>
      <div class="kpi-card">
        <div class="val green">{screener_hit}</div>
        <div class="lbl">companies: ROE&gt;15% &amp; D/E&lt;1 <span class="pass-pill">✓ PASS</span></div>
      </div>
      <div class="kpi-card">
        <div class="val amber">{debt_free_cos}</div>
        <div class="lbl">debt-free companies<br>(icr_label = Debt Free)</div>
      </div>
      <div class="kpi-card">
        <div class="val red">{high_lev}</div>
        <div class="lbl">companies with<br>high leverage flag</div>
      </div>
      <div class="kpi-card">
        <div class="val red">{icr_warn:,}</div>
        <div class="lbl">rows with ICR warning<br>(ICR &lt; 1.5)</div>
      </div>
      <div class="kpi-card">
        <div class="val green">52</div>
        <div class="lbl">unit tests passing <span class="pass-pill">✓ 0 failures</span></div>
      </div>
    </div>
  </div>

  <!-- ── Top 20 companies ──────────────────────────────────────── -->
  <div class="section">
    <div class="section-title">Top 20 Companies by Composite Quality Score — FY{latest_year}</div>
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Company</th>
          <th>Sector</th>
          <th class="num">NPM%</th>
          <th class="num">ROE%</th>
          <th class="num">ROCE%</th>
          <th class="num">D/E</th>
          <th class="num">ICR</th>
          <th class="num">RevCAGR 5yr</th>
          <th>CapEx</th>
          <th>Pattern</th>
          <th class="num">Score</th>
        </tr>
      </thead>
      <tbody>{table_rows}</tbody>
    </table>
  </div>

  <!-- ── Charts row ────────────────────────────────────────────── -->
  <div class="section">
    <div class="section-title">KPI Distributions</div>
    <div class="three-col">
      {bar_chart(cagr_flags,  title="Revenue CAGR 5yr Flags", colour="blue")}
      {bar_chart(patterns,    title="Capital Allocation Patterns", colour="purple")}
      {bar_chart(cfo_dist,    title="CFO Quality Labels", colour="green")}
    </div>
  </div>

  <!-- ── Second chart row ──────────────────────────────────────── -->
  <div class="section">
    <div class="two-col">
      {bar_chart(capex_dist,  title="CapEx Intensity Labels", colour="amber")}
      {bar_chart(pat_flags,   title="PAT CAGR 5yr Flags", colour="purple")}
    </div>
  </div>

  <!-- ── Sector heatmap ────────────────────────────────────────── -->
  <div class="section">
    <div class="section-title">Sector Heatmap — FY{latest_year} Averages</div>
    <table>
      <thead>
        <tr>
          <th>Sector</th>
          <th class="num">Avg ROE%</th>
          <th class="num">Avg ROCE%</th>
          <th class="num">Avg D/E</th>
          <th class="num">Companies</th>
        </tr>
      </thead>
      <tbody>{sector_rows}</tbody>
    </table>
  </div>

</div>

<div class="footer">
  <span>Financial Ratio Engine · Sprint 2 · Epic 02</span>
  <span>Generated {now} · financials.db · {total_rows:,} ratio rows</span>
</div>

</body>
</html>"""
    return html


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate Sprint 2 HTML Report")
    parser.add_argument("--db",  type=Path, default=DB_PATH)
    parser.add_argument("--out", type=Path, default=OUTPUT_HTML)
    args = parser.parse_args()

    print("Generating Sprint 2 HTML report…")
    html = build_report(args.db)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(html, encoding="utf-8")
    print(f"✅  Report written → {args.out.relative_to(ROOT)}")
    print(f"   Open: file://{args.out.resolve()}")


if __name__ == "__main__":
    main()
