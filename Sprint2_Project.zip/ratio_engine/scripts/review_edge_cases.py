"""
scripts/review_edge_cases.py
=============================
Day 13 — Edge Case Log Reviewer

Parses output/ratio_edge_cases.log, counts anomalies by category,
prints a formatted summary table, and writes a categorised
output/edge_case_summary.csv for team review.

Usage:
    python scripts/review_edge_cases.py [--log output/ratio_edge_cases.log]
"""

from __future__ import annotations
import argparse
import csv
import re
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

LOG_PATH     = ROOT / "output" / "ratio_edge_cases.log"
SUMMARY_CSV  = ROOT / "output" / "edge_case_summary.csv"

# ── Pattern matchers ──────────────────────────────────────────────────────────
_LINE_RE = re.compile(
    r"(?P<ts>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})"
    r"\s+\|\s+(?P<level>\w+)\s+\|"
    r"\s+(?P<event_type>\w+)\s+\|"
    r"\s+(?P<company>\w+)\s+FY(?P<year>\d{4})"
    r".*?\|\s+(?P<category>[\w_]+)\s*$"
)

# Fallback: lines that match SUPPRESSED pattern
_SUPPRESS_RE = re.compile(
    r"(?P<ts>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})"
    r"\s+\|\s+(?P<level>\w+)\s+\|"
    r"\s+SUPPRESSED\s+\|"
    r"\s+(?P<company>\w+)\s+FY(?P<year>\d{4})"
)

CATEGORY_DESCRIPTIONS = {
    "data_source_issue":  "Value likely wrong in source file (e.g. stored as decimal not %, stale field)",
    "version_difference": "Different fiscal-year alignment or formula version between source and engine",
    "formula_discrepancy": "Genuine formula difference — capital structure or EBIT definition mismatch",
    "suppressed_for_sector": "Flag suppressed because high leverage is structurally normal for Financials sector",
}


@dataclass
class AnomalyRecord:
    timestamp:  str
    level:      str
    event_type: str
    company_id: str
    year:       str
    category:   str
    raw_line:   str


def parse_log(log_path: Path) -> list[AnomalyRecord]:
    records: list[AnomalyRecord] = []
    if not log_path.exists():
        print(f"[WARN] Log not found: {log_path}")
        return records

    with open(log_path, encoding="utf-8") as f:
        for line in f:
            line = line.rstrip()
            m = _LINE_RE.search(line)
            if m:
                records.append(AnomalyRecord(
                    timestamp  = m.group("ts"),
                    level      = m.group("level"),
                    event_type = m.group("event_type"),
                    company_id = m.group("company"),
                    year       = m.group("year"),
                    category   = m.group("category"),
                    raw_line   = line,
                ))
                continue
            # Suppressed lines don't always end with a category token
            s = _SUPPRESS_RE.search(line)
            if s:
                records.append(AnomalyRecord(
                    timestamp  = s.group("ts"),
                    level      = s.group("level"),
                    event_type = "SUPPRESSED",
                    company_id = s.group("company"),
                    year       = s.group("year"),
                    category   = "suppressed_for_sector",
                    raw_line   = line,
                ))
    return records


def print_summary(records: list[AnomalyRecord]) -> None:
    if not records:
        print("\n✅ No anomalies found in the edge case log.\n")
        return

    total = len(records)
    by_cat: Counter = Counter(r.category for r in records)
    by_type: Counter = Counter(r.event_type for r in records)
    by_co: Counter = Counter(r.company_id for r in records)

    sep = "─" * 72

    print(f"\n{sep}")
    print(f"  EDGE CASE LOG REVIEW   ({total} entries)")
    print(sep)

    print("\n  By Category:")
    for cat, count in by_cat.most_common():
        desc = CATEGORY_DESCRIPTIONS.get(cat, "")
        print(f"    {count:>4}×  {cat:<30}  {desc}")

    print("\n  By Event Type:")
    for ev, count in by_type.most_common():
        print(f"    {count:>4}×  {ev}")

    print("\n  Most Anomalous Companies (top 10):")
    for co, count in by_co.most_common(10):
        print(f"    {count:>4}×  {co}")

    print(f"\n{sep}")
    print("  CATEGORY EXPLANATIONS")
    print(sep)
    for cat, desc in CATEGORY_DESCRIPTIONS.items():
        n = by_cat.get(cat, 0)
        print(f"\n  [{n}] {cat}")
        print(f"       {desc}")
    print()


def write_csv(records: list[AnomalyRecord], out_path: Path) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=[
            "timestamp", "level", "event_type", "company_id", "year",
            "category", "category_description",
        ])
        writer.writeheader()
        for r in records:
            writer.writerow({
                "timestamp":            r.timestamp,
                "level":                r.level,
                "event_type":           r.event_type,
                "company_id":           r.company_id,
                "year":                 r.year,
                "category":             r.category,
                "category_description": CATEGORY_DESCRIPTIONS.get(r.category, ""),
            })
    print(f"  Summary CSV → {out_path.relative_to(ROOT)}\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Edge Case Log Reviewer")
    parser.add_argument("--log", type=Path, default=LOG_PATH)
    parser.add_argument("--out", type=Path, default=SUMMARY_CSV)
    args = parser.parse_args()

    records = parse_log(args.log)
    print_summary(records)
    if records:
        write_csv(records, args.out)
    else:
        print(f"  Log path checked: {args.log}")


if __name__ == "__main__":
    main()
