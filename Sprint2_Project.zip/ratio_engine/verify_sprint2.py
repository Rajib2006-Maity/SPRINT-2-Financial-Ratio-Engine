"""
verify_sprint2.py
=================
Day 14 — Sprint 2 Exit Criteria Verification

Runs all 4 checks required for Definition of Done:
  1. Row count ≥ 1,100
  2. All 14 KPI columns populated (zero null-only columns)
  3. Screener: ROE > 15% AND D/E < 1 → 15–50 companies
  4. Manual spot-check: ROE and Revenue CAGR for 3 companies within 0.1%

Usage:
    python verify_sprint2.py [--db data/financials.db]
"""

from __future__ import annotations
import argparse
import math
import sys
import logging
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from src.db.schema import get_connection, DB_PATH
from src.analytics.screener import ScreenerCriteria, run_screener, print_screener_results

logging.basicConfig(level=logging.INFO, format="%(levelname)-8s %(message)s")
logger = logging.getLogger("verify")

REQUIRED_KPI_COLS = [
    "net_profit_margin_pct",
    "operating_profit_margin_pct",
    "return_on_equity_pct",
    "debt_to_equity",
    "interest_coverage",
    "asset_turnover",
    "free_cash_flow_cr",
    "capex_cr",
    "earnings_per_share",
    "book_value_per_share",
    "dividend_payout_ratio_pct",
    "total_debt_cr",
    "cash_from_operations_cr",
    "revenue_cagr_5yr",
    "pat_cagr_5yr",
    "eps_cagr_5yr",
    "composite_quality_score",
]

PASS = "✅ PASS"
FAIL = "❌ FAIL"
WARN = "⚠️  WARN"


# ---------------------------------------------------------------------------
# Check 1 — Row count
# ---------------------------------------------------------------------------
def check_row_count(conn, threshold: int = 1100) -> bool:
    count = conn.execute("SELECT COUNT(*) FROM financial_ratios").fetchone()[0]
    ok = count >= threshold
    logger.info("[1] Row Count   %s — %d rows  (need ≥ %d)", PASS if ok else FAIL, count, threshold)
    return ok


# ---------------------------------------------------------------------------
# Check 2 — All KPI columns populated
# ---------------------------------------------------------------------------
def check_kpi_columns(conn) -> bool:
    all_ok = True
    for col in REQUIRED_KPI_COLS:
        try:
            non_null = conn.execute(
                f"SELECT COUNT(*) FROM financial_ratios WHERE {col} IS NOT NULL"
            ).fetchone()[0]
            null_only = non_null == 0
            if null_only:
                logger.error("[2] KPI Columns ❌ '%s' is ALL NULL", col)
                all_ok = False
        except Exception as e:
            logger.error("[2] KPI Columns ❌ '%s' — error: %s", col, e)
            all_ok = False
    if all_ok:
        logger.info("[2] KPI Columns %s — all %d required columns have data", PASS, len(REQUIRED_KPI_COLS))
    return all_ok


# ---------------------------------------------------------------------------
# Check 3 — Screener
# ---------------------------------------------------------------------------
def check_screener(conn, db_path: Path) -> bool:
    screener_count = conn.execute(
        "SELECT COUNT(DISTINCT company_id) FROM financial_ratios "
        "WHERE return_on_equity_pct > 15 AND debt_to_equity < 1"
    ).fetchone()[0]
    ok = 15 <= screener_count <= 50
    status = PASS if ok else WARN
    logger.info(
        "[3] Screener    %s — %d companies pass ROE>15%% & D/E<1  (expect 15–50)",
        status, screener_count,
    )
    if screener_count > 0:
        results = run_screener(
            ScreenerCriteria(roe_min=15, de_max=1),
            db_path=db_path,
            limit=5,
        )
        logger.info("    Top 5 screener hits:")
        for r in results:
            logger.info(
                "      %-10s  ROE=%.1f%%  D/E=%.2f  Score=%.1f",
                r.company_id,
                r.return_on_equity_pct or 0,
                r.debt_to_equity or 0,
                r.composite_quality_score or 0,
            )
    return ok


# ---------------------------------------------------------------------------
# Check 4 — Manual spot-check (3 companies)
# ---------------------------------------------------------------------------
def check_spot_check(conn) -> bool:
    """
    Re-derive ROE and 5-yr Revenue CAGR from raw financials for 3 companies
    and compare against the stored ratio values.  Tolerance: 0.1%.
    """
    companies = [r[0] for r in conn.execute(
        "SELECT DISTINCT company_id FROM financials ORDER BY company_id LIMIT 3"
    ).fetchall()]

    all_ok = True
    for cid in companies:
        # --- ROE spot-check (most recent year) ---
        raw = conn.execute(
            "SELECT net_profit, equity_capital, reserves FROM financials "
            "WHERE company_id = ? ORDER BY year DESC LIMIT 1",
            (cid,),
        ).fetchone()
        stored = conn.execute(
            "SELECT return_on_equity_pct, year FROM financial_ratios "
            "WHERE company_id = ? ORDER BY year DESC LIMIT 1",
            (cid,),
        ).fetchone()

        if raw and stored and raw[0] is not None:
            equity = (raw[1] or 0) + (raw[2] or 0)
            manual_roe = (raw[0] / equity * 100) if equity > 0 else None
            stored_roe = stored[0]
            yr = stored[1]
            if manual_roe is not None and stored_roe is not None:
                diff = abs(manual_roe - stored_roe)
                ok = diff < 0.1
                all_ok = all_ok and ok
                logger.info(
                    "[4] Spot-check  %s — %s FY%s ROE: manual=%.4f%% stored=%.4f%% diff=%.6f%%",
                    PASS if ok else FAIL, cid, yr, manual_roe, stored_roe, diff,
                )

        # --- Revenue CAGR 5yr spot-check ---
        fin_rows = conn.execute(
            "SELECT year, sales FROM financials WHERE company_id = ? ORDER BY year",
            (cid,),
        ).fetchall()
        ratio_row = conn.execute(
            "SELECT year, revenue_cagr_5yr, revenue_cagr_5yr_flag FROM financial_ratios "
            "WHERE company_id = ? ORDER BY year DESC LIMIT 1",
            (cid,),
        ).fetchone()

        if ratio_row and ratio_row[2] == "NORMAL":
            end_yr  = ratio_row[0]
            start_yr = end_yr - 5
            sales_map = {r[0]: r[1] for r in fin_rows}
            sv = sales_map.get(start_yr)
            ev = sales_map.get(end_yr)
            if sv and ev and sv > 0 and ev > 0:
                manual_cagr = (math.pow(ev / sv, 1 / 5) - 1) * 100
                stored_cagr = ratio_row[1]
                diff = abs(manual_cagr - stored_cagr) if stored_cagr is not None else 999
                ok = diff < 0.1
                all_ok = all_ok and ok
                logger.info(
                    "[4] Spot-check  %s — %s FY%s RevCAGR5: manual=%.4f%% stored=%.4f%% diff=%.6f%%",
                    PASS if ok else FAIL, cid, end_yr, manual_cagr, stored_cagr, diff,
                )

    return all_ok


# ---------------------------------------------------------------------------
# Demo: 5 companies with all KPIs
# ---------------------------------------------------------------------------
def print_demo_table(conn) -> None:
    latest_year = conn.execute("SELECT MAX(year) FROM financial_ratios").fetchone()[0]
    rows = conn.execute(
        """
        SELECT company_id, year,
               net_profit_margin_pct, return_on_equity_pct,
               return_on_capital_employed, debt_to_equity,
               interest_coverage, revenue_cagr_5yr,
               capex_intensity_label, capital_allocation_pattern,
               composite_quality_score
        FROM financial_ratios
        WHERE year = ?
        ORDER BY composite_quality_score DESC NULLS LAST
        LIMIT 5
        """,
        (latest_year,),
    ).fetchall()

    print(f"\n{'─' * 95}")
    print(f"  DEMO — Top 5 Companies FY{latest_year} by Composite Quality Score")
    print(f"{'─' * 95}")
    header = f"  {'Company':<10} {'NPM%':>6} {'ROE%':>6} {'ROCE%':>6} {'D/E':>5} {'ICR':>6} {'RevCAGR':>8} {'CapEx':>16} {'Pattern':>20} {'Score':>6}"
    print(header)
    print(f"{'─' * 95}")
    for r in rows:
        icr = f"{r[6]:.1f}" if r[6] is not None else "D.Free"
        print(
            f"  {r[0]:<10} {_f(r[2]):>6} {_f(r[3]):>6} {_f(r[4]):>6} {_f(r[5]):>5} "
            f"{icr:>6} {_f(r[7]):>8} {(r[8] or '—'):>16} {(r[9] or '—'):>20} {_f(r[10]):>6}"
        )
    print(f"{'─' * 95}\n")


def _f(v) -> str:
    return f"{v:.1f}" if v is not None else "—"


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main() -> None:
    parser = argparse.ArgumentParser(description="Sprint 2 Exit Criteria Verification")
    parser.add_argument("--db", type=Path, default=DB_PATH)
    args = parser.parse_args()

    print("\n" + "═" * 60)
    print("  SPRINT 2 — DEFINITION OF DONE VERIFICATION")
    print("═" * 60 + "\n")

    with get_connection(args.db) as conn:
        r1 = check_row_count(conn)
        r2 = check_kpi_columns(conn)
        r3 = check_screener(conn, args.db)
        r4 = check_spot_check(conn)
        print_demo_table(conn)

    passed = sum([r1, r2, r3, r4])
    print("\n" + "═" * 60)
    print(f"  RESULT: {passed}/4 checks passed")
    print("═" * 60 + "\n")
    sys.exit(0 if passed == 4 else 1)


if __name__ == "__main__":
    main()
