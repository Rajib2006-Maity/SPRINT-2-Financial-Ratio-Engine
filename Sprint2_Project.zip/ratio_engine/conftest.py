"""
conftest.py
===========
Shared pytest fixtures for the Ratio Engine test suite.
"""

import pytest
import sqlite3
import tempfile
from pathlib import Path

# Make sure the src package is importable from tests
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))


@pytest.fixture(scope="session")
def tmp_db_path(tmp_path_factory) -> Path:
    """Provide a fresh SQLite DB for the session."""
    return tmp_path_factory.mktemp("db") / "test_financials.db"


@pytest.fixture(scope="session")
def seeded_db(tmp_db_path) -> Path:
    """
    Seed a small in-memory-style SQLite DB with 5 companies × 15 years
    for integration-level tests.
    """
    from src.db.schema import create_all_tables, get_connection
    from src.db.loader import seed_synthetic_data

    seed_synthetic_data(db_path=tmp_db_path, n_companies=5)
    return tmp_db_path


@pytest.fixture
def sample_row() -> dict:
    """A typical financial data row for unit tests."""
    return {
        "company_id":        "CO001",
        "year":              2023,
        "broad_sector":      "Technology",
        "sales":             10_000.0,
        "operating_profit":  2_000.0,
        "other_income":      150.0,
        "interest":          300.0,
        "depreciation":      400.0,
        "net_profit":        1_100.0,
        "eps":               22.0,
        "equity_capital":    100.0,
        "reserves":          4_900.0,
        "borrowings":        2_000.0,
        "total_assets":      12_000.0,
        "investments":       1_500.0,
        "operating_activity": 1_400.0,
        "investing_activity": -800.0,
        "financing_activity": -300.0,
        "opm_percentage":    20.0,
        "roce_percentage":   None,
        "roe_percentage":    None,
        "dividend_payout":   30.0,
        "book_value":        100.0,
    }


@pytest.fixture
def financial_sector_row(sample_row) -> dict:
    """Same as sample_row but in the Financials broad sector."""
    row = sample_row.copy()
    row["broad_sector"] = "Financials"
    row["borrowings"] = 40_000.0   # high leverage — normal for banks
    return row
